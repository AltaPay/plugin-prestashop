<?php
/**
 * NOTICE OF LICENSE
 *
 * This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * @author Simion Zafiu <simion.zafiu@valitor.com>
 * @copyright Copyright (C) 2019 Valitor  (https://valitor.com)
 * @license GNU General Public License v3.0 <http://www.gnu.org/licenses/gpl-3.0.html>
 */

class Terminal extends ObjectModel
{
    public $id_terminal;
    public $display_name;
    public $remote_name;
    public $payment_type;
    public $currency;
    public $icon_filename;

    /** @var boolean Enabled or disabled */
    public $active;
    public $position;

    public static $definition = array(
        'table' => 'valitor_terminals',
        'primary' => 'id_terminal',
        'fields' => array(
            'id_terminal' => array('type' => self::TYPE_INT, 'validate' => 'isNullOrUnsignedId', 'copy_post' => false),
            'display_name' => array('type' => self::TYPE_STRING, 'required' => true, 'size' => 255),
            'remote_name' => array('type' => self::TYPE_STRING, 'required' => true, 'size' => 255),
            'payment_type' => array('type' => self::TYPE_STRING, 'required' => true, 'size' => 32),
            'currency' => array('type' => self::TYPE_STRING, 'required' => true, 'size' => 100),
            'icon_filename' => array('type' => self::TYPE_STRING, 'required' => true, 'size' => 100),
            'active' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'position' => array('type' => self::TYPE_INT, 'validate' => 'isNullOrUnsignedId'),
        ),
    );

    public function __construct($id_terminal = null)//, $id_lang = null)
    {
        parent::__construct($id_terminal);
    }

    public static function getTerminals()
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS("
			SELECT * FROM `"._DB_PREFIX_."valitor_terminals` ORDER BY `id_terminal` ASC
		");
    }

    public static function getActiveTerminals()
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS("
			SELECT * FROM `"._DB_PREFIX_."valitor_terminals` WHERE active = 1 ORDER BY `display_name` ASC
		");
    }

    public static function getActiveTerminalsForCurrency($currency = false)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS("
            SELECT * FROM `"
            ._DB_PREFIX_."valitor_terminals` WHERE active = 1 AND currency = '".$currency."' ORDER BY `display_name` ASC
		");
    }
}
