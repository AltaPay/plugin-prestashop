<?php
/**
 * Valitor module for Prestashop
 *
 * Copyright © 2020 Valitor. All rights reserved.
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

require_once _PS_MODULE_DIR_ . '/valitor/lib/valitor/valitor-php-sdk/lib/ValitorCallbackHandler.class.php';
require_once _PS_MODULE_DIR_ . '/valitor/helpers.php';

class ValitorCallbackfailModuleFrontController extends ModuleFrontController
{
    /**
     * Method to add external assets
     */
    public function setMedia()
    {
        parent::setMedia();
        $this->addCSS(($this->module->getPathUri()) . 'css/valitor.css', 'all');
    }

    /**
     * Method to follow when callback fail is being triggered
     * @throws Exception
     */
    public function postProcess()
    {
        $xml = Tools::getValue('xml');
        $callbackHandler = new ValitorCallbackHandler();
        $response = $callbackHandler->parseXmlResponse($xml);

        $shopOrderId = $response->getPrimaryPayment()->getShopOrderId();

        // load the cart
        $cart = getCartFromUniqueId($shopOrderId);
        if (!Validate::isLoadedObject($cart)) {
            die('Could not load cart - exiting');
        }

        $status = Tools::getValue('payment_status');
        if ($status == 'epayment_cancelled') {
            $unique_id = Tools::getValue('shop_orderid');
            // updated transaction record to cancel
            $pI = pSQL($unique_id);
            $q = 'UPDATE `' . _DB_PREFIX_ . 'valitor_transaction` set `is_cancelled`=1 WHERE `unique_id`=\'' .$pI. '\'';
            Db::getInstance()->Execute($q);


            // redirect back to either standard or quick checkout process
            $controller = Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc.php' : 'order.php';
            $pLink = $this->context->link->getPageLink($controller);
            $vCan = 'valitor_cancel=1&isPaymentStep=true&step=3#valitor_cancel';
            $location = $pLink . (strpos($controller, '?') !== false ? '&' : '?') . $vCan ;
            Tools::redirectLink($location);
        } else {
            $mErM = $response->getMerchantErrorMessage();
            $cId = $cart->id;
            $mNa = $this->module->name;
            $mId = $this->module->id;
            Logger::addLog('Payment failure for cart ' . $cId . '. Error Message: ' . $mErM, 3, 2001, $mNa, $mId, true);

            /*redirect user back to checkout payment step,
            assume a failure occured creating the URL until a payment url is received*/
            $controller = Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc.php' : 'order.php';

            $css_dir = null;
            $this->context->smarty->assign(array(
                'errorText' => $response->getCardHolderErrorMessage(),
                'unique_id' => $response->getPrimaryPayment()->getShopOrderId(),
                'payment_id' => $response->getPrimaryPayment()->getId(),
                'this_path' => $this->module->getPathUri(),
                'this_path_valitor' => $this->module->getPathUri(),
                'this_path_ssl' => Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'modules/' . $mNa . '/',
                'css_dir' => $css_dir,
            ));
            //Prestashop 1.6 and Prestashop 1.7 have different declarations of $this->setTemplate()
            if (_PS_VERSION_ >= '1.7.0.0') {
                $this->setTemplate('module:valitor/views/templates/front/payment_error17.tpl');
            } else {
                $this->setTemplate('payment_error.tpl');
            }
        }
    }
}
