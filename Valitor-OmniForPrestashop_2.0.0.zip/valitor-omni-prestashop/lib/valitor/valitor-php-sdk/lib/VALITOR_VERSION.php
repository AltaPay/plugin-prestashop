<?php
// Update this with the latest GIT tag
define('VALITOR_VERSION', 'PHPSDK/1.1.0');
