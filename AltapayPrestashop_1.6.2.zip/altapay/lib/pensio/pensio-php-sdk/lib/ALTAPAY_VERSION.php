<?php
// Update this with the latest GIT tag
define('ALTAPAY_VERSION', 'PHPSDK/1.0.6');