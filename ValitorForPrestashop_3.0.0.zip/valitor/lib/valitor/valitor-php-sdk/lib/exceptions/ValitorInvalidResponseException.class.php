<?php

class ValitorInvalidResponseException extends ValitorMerchantAPIException
{
    
}