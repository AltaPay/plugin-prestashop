<?php

if(!defined('VALITOR_API_ROOT'))
{
	define('VALITOR_API_ROOT',dirname(__DIR__));
}

require_once(VALITOR_API_ROOT.'/http/ValitorHttpRequest.class.php');
require_once(VALITOR_API_ROOT.'/http/ValitorHttpResponse.class.php');

interface IValitorHttpUtils
{
	/**
	 * @return ValitorHttpResponse
	 */
	public function requestURL(ValitorHttpRequest $request);
}