<?php
/**
 * Valitor module for Prestashop
 *
 * Copyright © 2020 Valitor. All rights reserved.
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

/**
 * Function library for VALITOR payment module
 *
 * @since 04-2016
 */

/**
 * Determine which payment method to display in PrestaShop backoffice
 * i.e. MobilePay Visa, CreditCard, etc.
 * @param array $transactionInfo
 * @return array
 */

function transactionInfo($transactionInfo = array())
{
    $pluginName = 'valitor';
    $pluginVersion = '3.1.0';

    // transaction info
    $transactionInfo['ecomPlatform'] = 'Prestashop';
    $transactionInfo['ecomVersion'] = _PS_VERSION_;
    $transactionInfo['valitorPluginName'] = $pluginName;
    $transactionInfo['valitorPluginVersion'] = $pluginVersion;
    $transactionInfo['otherInfo'] = 'storeName-' . Configuration::get('PS_SHOP_NAME');

    return $transactionInfo;
}

function determinePaymentMethodForDisplay($response)
{
    $paymentNature = $response->getPrimaryPayment()->getPaymentNature();

    if ($paymentNature == "Wallet") {
        $paymentMethod = $response->getPrimaryPayment()->getPaymentSchemeName();
    } elseif ($paymentNature == "CreditCard") {
        $paymentMethod = $paymentNature;
    } elseif ($paymentNature == "CreditCardWallet") {
        $paymentMethod = $response->getPrimaryPayment()->getPaymentSchemeName();
    } else {
        $paymentMethod = $paymentNature;
    }

    return $paymentMethod;
}

/**
 * Use the unique ID to determine cart
 * @param $uniqueId
 * @return bool|Cart
 */

function getCartFromUniqueId($uniqueId)
{
    $cart = false;
    $results = Db::getInstance()->getRow('SELECT id_cart 
    FROM `' . _DB_PREFIX_ . 'valitor_transaction` 
    WHERE unique_id=\'' . $uniqueId . '\'');
    $cart = new Cart((int)$results['id_cart']);

    return $cart;
}

/**
 * Use the unique ID to fetch the created from it (if any)
 * @param $uniqueId
 * @return Order
 */

function getOrderFromUniqueId($uniqueId)
{
    $results = Db::getInstance()->getRow('SELECT id_order 
    FROM `' . _DB_PREFIX_ . 'valitor_order` 
    WHERE unique_id = \'' . $uniqueId . '\'');
    $order = new Order((int)$results['id_order']);

    return $order;
}

/**
 * Method for marking and updating status of order as captured in case of a captured action in database
 * @param $paymentId
 * @param array $orderlines
 * @return bool
 */
function markAsCaptured($paymentId, $orderlines = array())
{
    $sql = 'UPDATE '
        . _DB_PREFIX_ . 'valitor_order SET requireCapture = 0 WHERE payment_id = ' . $paymentId . ' LIMIT 1';
    Db::getInstance()->Execute($sql);

    if (count($orderlines) > 0) {
        foreach ($orderlines as $productId => $quantity) {
            if ($quantity == 0) {
                continue;
            }

            $result = Db::getInstance()->getRow('SELECT captured 
            FROM ' . _DB_PREFIX_ . 'valitor_orderlines WHERE valitor_payment_id = "'
                . $paymentId . '" AND product_id = ' . $productId);

            if (isset($result['captured'])) {
                $quantity += $result['captured'];
                $sqlUpdateCapture = 'UPDATE ' . _DB_PREFIX_ .
                    'valitor_orderlines SET captured = ' . $quantity .
                    ' WHERE valitor_payment_id = ' . $paymentId;
                Db::getInstance()->Execute($sqlUpdateCapture);
            } else {
                $sqlOrderLine = 'INSERT INTO ' . _DB_PREFIX_ .
                    'valitor_orderlines (valitor_payment_id, product_id, captured) 
                VALUES("' . $paymentId . '", "' . $productId . '", ' . $quantity . ')';
                Db::getInstance()->Execute($sqlOrderLine);
            }
        }
    }

    return true;
}

/**
 * Method for marking and updating status of order as refund in case of a refund action in database
 * @param $paymentId
 * @param array $orderlines
 * @return bool
 */
function markAsRefund($paymentId, $orderlines = array())
{
    $sqlRequireCapture = 'SELECT requireCapture 
    FROM ' . _DB_PREFIX_ . 'valitor_order WHERE payment_id = ' . $paymentId;
    $result = Db::getInstance()->getRow($sqlRequireCapture);
    // Only payments which have been captured/partial captured will be considered
    if (isset($result['requireCapture']) && $result['requireCapture'] == 0) {
        if (count($orderlines) > 0) {
            foreach ($orderlines as $productId => $quantity) {
                if ($quantity == 0) {
                    continue;
                }
                $sqlGetRefundedFieldValue = 'SELECT captured, refunded 
                FROM ' . _DB_PREFIX_ . 'valitor_orderlines WHERE valitor_payment_id = "'
                    . $paymentId . '" AND product_id = ' . $productId;
                $result = Db::getInstance()->getRow($sqlGetRefundedFieldValue);
                if (isset($result['refunded'])) {
                    $quantity += $result['refunded'];
                    // If the amount of refunded items is bigger than the actual captured amount than set the max amount
                    if ($quantity > $result['captured']) {
                        $quantity = $result['captured'];
                    }

                    // Update only of there is a capture for this product
                    $sql = "UPDATE " . _DB_PREFIX_ . "valitor_orderlines SET refunded = "
                        . $quantity . " WHERE valitor_payment_id = '" . $paymentId . "' AND product_id = " . $productId;
                    Db::getInstance()->Execute($sql);
                } else {
                    //product which have not been captured cannot be refunded
                    //maybe throw an error here ...
                    continue;
                }
            }
        }
        return true;
    } else {
        return false;
    }
}

/**
 * Method to update latest error message from gateway response in database
 * @param $paymentId
 * @param $latestError
 */
function saveLastErrorMessage($paymentId, $latestError)
{

    $sql = 'UPDATE 
    ' . _DB_PREFIX_ . 'valitor_order SET latestError = \'' . $latestError . '\' WHERE payment_id='
        . $paymentId . ' LIMIT 1';
    Db::getInstance()->Execute($sql);
}

/**
 * Method for updating payment status in database
 * @param $paymentId
 * @param $paymentStatus
 */
function updatePaymentStatus($paymentId, $paymentStatus)
{
    $sql = 'UPDATE 
    ' . _DB_PREFIX_ . 'valitor_order SET paymentStatus = \'' . $paymentStatus . '\' WHERE payment_id='
        . $paymentId . ' LIMIT 1';
    Db::getInstance()->Execute($sql);
}

/**
 * Method for creating orders at prestashop backend
 * @param $response
 * @param $current_order
 * @param string $payment_status
 */
function createValitorOrder($response, $current_order, $payment_status = 'succeeded')
{

    $uniqueId = $response->getPrimaryPayment()->getShopOrderId();
    $paymentId = $response->getPrimaryPayment()->getId();
    $cardMask = $response->getPrimaryPayment()->getMaskedPan();
    $cardToken = $response->getPrimaryPayment()->getCreditCardToken();
    $cardExpiryMonth = $response->getPrimaryPayment()->getCreditCardExpiryMonth();
    $cardExpiryYear = $response->getPrimaryPayment()->getCreditCardExpiryYear();
    $cardBrand = $response->getPrimaryPayment()->getPaymentSchemeName();
    $paymentType = $response->getPrimaryPayment()->getAuthType();
    $paymentTerminal = $response->getPrimaryPayment()->getTerminal();
    $paymentNature = $response->getPrimaryPayment()->getPaymentNature();
    $paymentStatus = $payment_status;
    $requireCapture = 0;
    if ($paymentType == 'payment') {
        $requireCapture = 1;
    }
    $cardExpiryDate = 0;
    if($cardExpiryMonth && $cardExpiryYear) {
        $cardExpiryDate = $cardExpiryMonth.'/'.$cardExpiryYear;
    }

    $errorCode = null;
    $errorText = null;

    $customerInfo = $response->getPrimaryPayment()->getCustomerInfo();
    //$billingCountry = $customerInfo->getBillingAddress()->getCountry();
    $cardCountry = $customerInfo->getCountryOfOrigin()->getCountry();

    //insert into order log
    $sql = 'INSERT INTO `' . _DB_PREFIX_ . 'valitor_order`
		(id_order, unique_id, payment_id, cardMask, cardToken, cardBrand, cardExpiryDate, cardCountry, 
        paymentType, paymentTerminal, paymentStatus, paymentNature, requireCapture, errorCode, errorText, date_add) 
        VALUES ' .
        "('" . $current_order->id . "', '" . pSQL($uniqueId) . "', '"
        . pSQL($paymentId) . "', '" . pSQL($cardMask) . "', '"
        . pSQL($cardToken) . "', '" . pSQL($cardBrand) . "', '"
        . pSQL($cardExpiryDate) . "', '"
        . pSQL($cardCountry) . "', '" . pSQL($paymentType) . "', '"
        . pSQL($paymentTerminal) . "', '"
        . pSQL($paymentStatus) . "', '" . pSQL($paymentNature) . "', '"
        . pSQL($requireCapture) . "', '" . pSQL($errorCode) . "', '"
        . pSQL($errorText) . "', '" . time() . "')";
    Db::getInstance()->Execute($sql);

    if (Validate::isLoadedObject($current_order)) {
        $payment = $current_order->getOrderPaymentCollection();
        if (isset($payment[0])) {
            $payment[0]->transaction_id = pSQL($uniqueId);
            $payment[0]->card_number = pSQL($cardMask);
            $payment[0]->card_brand = pSQL($cardBrand);
            // $payment[0]->card_expiration = pSQL($cardExp);    //not provided
            $payment[0]->save();
        }
    }
}

/**
 * Method for conversion of date format
 * @param $date
 * @return string
 * @throws Exception
 */
function convertDateTimeFormat($date)
{
    $dateTime = new DateTime($date);
    return $dateTime->format('Y-m-d');
}


/**
 * Method for Valitor api login
 * @return string|ValitorMerchantAPI
 * @throws Exception
 */
function apiLogin()
{
    $config = Configuration::getMultiple(array(
        'VALITOR_USERNAME',
        'VALITOR_PASSWORD',
        'VALITOR_URL'
    ));

       $api = new ValitorMerchantAPI($config['VALITOR_URL'],
            $config['VALITOR_USERNAME'], $config['VALITOR_PASSWORD'], null);
        try {
            $api->login();
        } catch (Exception $e) {
            return $e->getMessage();
        }

    return $api;
}

/**
 * Method for getting order details created using plugin
 * @param $orderID
 * @return mixed
 */
function getValitorOrderDetails($orderID)
{
    $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'valitor_order` WHERE id_order =' . $orderID;
    return Db::getInstance()->executeS($sql);
}

/**
 * Get terminal id based on terminal remote name
 * @param $terminalRemoteName
 * @return mixed
 */
function getTerminalId($terminalRemoteName)
{
    $sql = 'SELECT id_terminal FROM `'._DB_PREFIX_.'valitor_terminals` WHERE `remote_name`='."'$terminalRemoteName'";
    return Db::getInstance()->executeS($sql);
}

/**
 * Get terminal control status based on terminal remote name
 * @param $terminalRemoteName
 * @return mixed
 */
function getTerminalTokenControlStatus($terminalRemoteName)
{
    $sql = 'SELECT ccTokenControl_ FROM `'._DB_PREFIX_.'valitor_terminals` WHERE `remote_name`='."'$terminalRemoteName'";
    return Db::getInstance()->executeS($sql);
}

