<?php

class AltapayInvalidResponseException extends AltapayMerchantAPIException
{
    
}