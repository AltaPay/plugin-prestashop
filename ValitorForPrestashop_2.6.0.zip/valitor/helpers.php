<?php
/**
 * NOTICE OF LICENSE
 *
 * This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * @author Simion Zafiu <simion.zafiu@valitor.com>
 * @copyright Copyright (C) 2019 Valitor  (https://valitor.com)
 * @license GNU General Public License v3.0 <http://www.gnu.org/licenses/gpl-3.0.html>
 */

/**
 * Function library for VALITOR payment module
 *
 * @since 04-2016
 */

/**
 * Determine which payment method to display in PrestaShop backoffice
 * i.e. MobilePay Visa, CreditCard, etc.
 */

function transactionInfo($transactionInfo = array())
{
    $pluginName = 'valitor';
    $pluginVersion = '2.6.0';

    // transaction info
    $transactionInfo['ecomPlatform'] = 'Prestashop';
    $transactionInfo['ecomVersion'] = _PS_VERSION_;
    $transactionInfo['valitorPluginName'] = $pluginName;
    $transactionInfo['valitorPluginVersion'] = $pluginVersion;
    $transactionInfo['otherInfo'] = 'storeName-'.Configuration::get('PS_SHOP_NAME');

    return $transactionInfo;
}

function determine_payment_method_for_display($response)
{
    $paymentNature = $response->getPrimaryPayment()->getPaymentNature();

    if ($paymentNature == "Wallet") {
        $paymentMethod = $response->getPrimaryPayment()->getPaymentSchemeName();
    } elseif ($paymentNature == "CreditCard") {
        $paymentMethod = $paymentNature;
    } elseif ($paymentNature == "CreditCardWallet") {
        $paymentMethod = $response->getPrimaryPayment()->getPaymentSchemeName();
    } else {
        $paymentMethod = $paymentNature;
    }

    return $paymentMethod;
}

/**
 * Use the unique ID to determine cart
 */

function get_cart_from_unique_id($unique_id)
{
    $cart = false;
    $results = Db::getInstance()->getRow('SELECT id_cart 
    FROM `' . _DB_PREFIX_ . 'valitor_transaction` 
    WHERE unique_id=\'' . $unique_id . '\'');
    $cart = new Cart((int) $results['id_cart']);

    return $cart;
}

/**
 * Use the unique ID to fetch the created from it (if any)
 */

function get_order_from_unique_id($unique_id)
{
    $results = Db::getInstance()->getRow('SELECT id_order 
    FROM `' . _DB_PREFIX_ . 'valitor_order` 
    WHERE unique_id = \'' . $unique_id . '\'');
    $order = new Order((int) $results['id_order']);

    return $order;
}

function mark_as_captured($payment_id, $orderlines = array())
{
    $sql = 'UPDATE '
    . _DB_PREFIX_ . 'valitor_order SET requireCapture = 0 WHERE payment_id = ' . $payment_id . ' LIMIT 1';
    Db::getInstance()->Execute($sql);
    
    if (count($orderlines) > 0) {
        foreach ($orderlines as $productId => $quantity) {
            if ($quantity == 0) {
                continue;
            }
            
            $result = Db::getInstance()->getRow('SELECT captured 
            FROM ' . _DB_PREFIX_ . 'valitor_orderlines WHERE valitor_payment_id = "'
            . $payment_id . '" AND product_id = ' . $productId);

            if (isset($result['captured'])) {
                $quantity += $result['captured'];
                $sqlUpdateCapture = 'UPDATE ' . _DB_PREFIX_ .
                'valitor_orderlines SET captured = ' . $quantity .
                ' WHERE valitor_payment_id = ' . $payment_id;
                Db::getInstance()->Execute($sqlUpdateCapture);
            } else {
                $sqlOrderLine = 'INSERT INTO ' . _DB_PREFIX_ .
                'valitor_orderlines (valitor_payment_id, product_id, captured) 
                VALUES("' . $payment_id . '", "' . $productId . '", ' . $quantity . ')';
                Db::getInstance()->Execute($sqlOrderLine);
            }
        }
    }

    return true;
}

function mark_as_refunded($payment_id, $orderlines = array())
{
    $sqlRequireCapture = 'SELECT requireCapture 
    FROM ' . _DB_PREFIX_ . 'valitor_order WHERE payment_id = ' . $payment_id;
    $result = Db::getInstance()->getRow($sqlRequireCapture);
    // Only payments which have been captured/partial captured will be considered
    if (isset($result['requireCapture']) && $result['requireCapture'] == 0) {
        if (count($orderlines) > 0) {
            foreach ($orderlines as $productId => $quantity) {
                if ($quantity == 0) {
                    continue;
                }
                $sqlGetRefundedFieldValue = 'SELECT captured, refunded 
                FROM ' . _DB_PREFIX_ . 'valitor_orderlines WHERE valitor_payment_id = "'
                . $payment_id . '" AND product_id = ' . $productId;
                $result = Db::getInstance()->getRow($sqlGetRefundedFieldValue);
                if (isset($result['refunded'])) {
                    $quantity += $result['refunded'];
                    // If the amount of refunded items is bigger than the actual captured amount than set the max amount
                    if ($quantity > $result['captured']) {
                        $quantity = $result['captured'];
                    }

                    // Update only of there is a capture for this product
                    $sql = "UPDATE " . _DB_PREFIX_ . "valitor_orderlines SET refunded = "
                    . $quantity . " WHERE valitor_payment_id = '" . $payment_id . "' AND product_id = " . $productId;
                    Db::getInstance()->Execute($sql);
                } else {
                    //product which have not been captured cannot be refunded
                    //maybe throw an error here ...
                    continue;
                }
            }
        }
        return true;
    } else {
        return false;
    }
}

function saveLastErrorMessage($payment_id, $latestError)
{

    $sql = 'UPDATE 
    ' . _DB_PREFIX_ . 'valitor_order SET latestError = \'' . $latestError . '\' WHERE payment_id='
    . $payment_id . ' LIMIT 1';
    Db::getInstance()->Execute($sql);
}

function create_valitor_order($response, $current_order, $payment_status = 'succeeded')
{

    $unique_id = $response->getPrimaryPayment()->getShopOrderId();
    $payment_id = $response->getPrimaryPayment()->getId();
    $cardMask = $response->getPrimaryPayment()->getMaskedPan();
    $cardToken = $response->getPrimaryPayment()->getCreditCardToken();
    $cardBrand = $response->getPrimaryPayment()->getPaymentSchemeName();
    $paymentType = $response->getPrimaryPayment()->getAuthType();
    $paymentNature = $response->getPrimaryPayment()->getPaymentNature();
    $paymentStatus = $payment_status;
    $requireCapture = 0;
    if ($paymentType == 'payment') {
        $requireCapture = 1;
    }

    $errorCode = null;
    $errorText = null;

    $customerInfo = $response->getPrimaryPayment()->getCustomerInfo();
    //$billingCountry = $customerInfo->getBillingAddress()->getCountry();
    $cardCountry = $customerInfo->getCountryOfOrigin()->getCountry();

    //insert into order log
    $sql = 'INSERT INTO `' . _DB_PREFIX_ . 'valitor_order`
		(id_order, unique_id, payment_id, cardMask, cardToken, cardBrand, cardCountry, 
        paymentType, paymentStatus, paymentNature, requireCapture, errorCode, errorText, date_add) 
        VALUES ' .
    "('" . $current_order->id . "', '" . pSQL($unique_id) . "', '"
    . pSQL($payment_id) . "', '" . pSQL($cardMask) . "', '"
    . pSQL($cardToken) . "', '" . pSQL($cardBrand) . "', '"
    . pSQL($cardCountry) . "', '" . pSQL($paymentType) . "', '"
    . pSQL($paymentStatus) . "', '" . pSQL($paymentNature) . "', '"
    . pSQL($requireCapture) . "', '" . pSQL($errorCode) . "', '"
    . pSQL($errorText) . "', '" . time() . "')";
    Db::getInstance()->Execute($sql);

    if (Validate::isLoadedObject($current_order)) {
        $payment = $current_order->getOrderPaymentCollection();
        if (isset($payment[0])) {
            $payment[0]->transaction_id = pSQL($unique_id);
            $payment[0]->card_number = pSQL($cardMask);
            $payment[0]->card_brand = pSQL($cardBrand);
            // $payment[0]->card_expiration = pSQL($cardExp);    //not provided
            $payment[0]->save();
        }
    }
}
