<?php

if(!defined('VALITOR_API_ROOT'))
{
	define('VALITOR_API_ROOT',dirname(__DIR__));
}

require_once(VALITOR_API_ROOT.'/response/ValitorAbstractResponse.class.php');

class ValitorCreateInvoiceReservationResponse extends ValitorAbstractResponse
{
	private $result;
	
	public function __construct(SimpleXmlElement $xml)
	{
		parent::__construct($xml);
		
		if($this->getErrorCode() === '0')
		{
			$this->result = (string)$xml->Body->Result;
		}
	}
	
	public function wasSuccessful()
	{
		return $this->getErrorCode() === '0' && $this->result == 'Success';
	}
}