<?php

if(!defined('VALITOR_API_ROOT'))
{
	define('VALITOR_API_ROOT',__DIR__);
}

require_once(VALITOR_API_ROOT.'/helpers.php');


class ValitorMerchantAPI
{
	private $baseURL, $username, $password;
	private $connected = false;
	/**
	 * @var IValitorCommunicationLogger
	 */
	private $logger;
	private $httpUtil;

	public function __construct($baseURL, $username, $password, IValitorCommunicationLogger $logger = null, IValitorHttpUtils $httpUtil = null)
	{
		$this->connected = false;
		$this->baseURL = rtrim($baseURL, '/');
		$this->username = $username;
		$this->password = $password;
		$this->logger = $logger;
		
		if(is_null($httpUtil))
		{
			if(function_exists('curl_init'))
			{
				$httpUtil = new ValitorCurlBasedHttpUtils();
			}
			else if(ini_get('allow_url_fopen'))
			{
				$httpUtil = new ValitorFOpenBasedHttpUtils();
			}
			else
			{
				throw new Exception("Neither allow_url_fopen nor cURL is installed, we cannot communicate with Valitor's Payment Gateway without at least one of them.");
			}
		}
		$this->httpUtil = $httpUtil;
	}

	private function checkConnection()
	{
		if(!$this->connected)
		{
			throw new Exception("Not Connected, invoke login() before using any API calls");
		}
	}
	
	public function isConnected()
	{
		return $this->connected;
	}

	private function maskPan($pan)
	{
		if(strlen($pan) >= 10)
		{
			return  substr($pan, 0, 6).str_repeat('x', strlen($pan) - 10).substr($pan, -4);
		}
		else
		{
			return $pan;
		}
	}

	private function callAPIMethod($method, array $args = array())
	{
		$absoluteUrl = $this->baseURL."/merchant/API/".$method;

		if(!is_null($this->logger))
		{
			$loggedArgs = $args;
			if(isset($loggedArgs['cardnum']))
			{
				$loggedArgs['cardnum'] = $this->maskPan($loggedArgs['cardnum']);
			}
			if(isset($loggedArgs['cvc']))
			{
				$loggedArgs['cvc'] = str_repeat('x', strlen($loggedArgs['cvc']));
			}
			$logId = $this->logger->logRequest($absoluteUrl.'?'.http_build_query($loggedArgs));
		}

		$request = new ValitorHttpRequest();
		$request->setUrl($absoluteUrl);
		$request->setParameters($args);
		$request->setUser($this->username);
		$request->setPass($this->password);
		$request->setMethod('POST');
		$request->addHeader('x-valitor-client-version: '.VALITOR_VERSION);

		$response = $this->httpUtil->requestURL($request);
		
		if(!is_null($this->logger))
		{
			$this->logger->logResponse($logId, print_r($response, true));
		}

		if($response->getConnectionResult() == ValitorHttpResponse::CONNECTION_OKAY)
		{
			if($response->getHttpCode() == 200)
			{
				if(stripos($response->getContentType(), "text/xml") !== false)
				{
					try
					{
						return new SimpleXMLElement($response->getContent());
					}
					catch(Exception $e)
					{
						if($e->getMessage() == 'String could not be parsed as XML')
						{
							throw new ValitorInvalidResponseException("Unparsable XML Content in response");
						}
						throw new ValitorUnknownMerchantAPIException($e);
					}
				}
				elseif (stripos($response->getContentType(), "text/csv") !== false)
				{
					return $response->getContent();
				}
				else
				{
					throw new ValitorInvalidResponseException("Non XML ContentType (was: ".$response->getContentType().")");
				}
			}
			else if($response->getHttpCode() == 401)
			{
				throw new ValitorUnauthorizedAccessException($absoluteUrl, $this->username);
			}
			else
			{
				throw new ValitorInvalidResponseException("Non HTTP 200 Response: ".$response->getHttpCode());
			}
		}
		else if($response->getConnectionResult() == ValitorHttpResponse::CONNECTION_REFUSED)
		{
			throw new ValitorConnectionFailedException($absoluteUrl, 'Connection refused');
		}
		else if($response->getConnectionResult() == ValitorHttpResponse::CONNECTION_TIMEOUT)
		{
			throw new ValitorConnectionFailedException($absoluteUrl, 'Connection timed out');
		}
		else if($response->getConnectionResult() == ValitorHttpResponse::CONNECTION_READ_TIMEOUT)
		{
			throw new ValitorRequestTimeoutException($absoluteUrl);
		}
		else
		{
			throw new ValitorUnknownMerchantAPIException();
		}
	}

	/**
	 * @return ValitorFundingListResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function getFundingList($page=0)
	{
		$this->checkConnection();

		return new ValitorFundingListResponse($this->callAPIMethod('fundingList', array('page'=>$page)));
	}
	
	/**
	 * @return string|boolean
	 * @throws ValitorMerchantAPIException
	 */
	public function downloadFundingCSV(ValitorAPIFunding $funding)
	{
		$this->checkConnection();

		$request = new ValitorHttpRequest();
		$request->setUrl($funding->getDownloadLink());
		$request->setUser($this->username);
		$request->setPass($this->password);
		$request->setMethod('GET');
		
		$response = $this->httpUtil->requestURL($request);
		
		if($response->getHttpCode() == 200)
		{
			return $response->getContent();
		}
		
		return false;
	}

	/**
	 * @return string|boolean
	 * @throws ValitorMerchantAPIException
	 */
	public function downloadFundingCSVByLink($downloadLink)
	{
		$this->checkConnection();

		$request = new ValitorHttpRequest();

		$request->setUrl($downloadLink);
		$request->setUser($this->username);
		$request->setPass($this->password);
		$request->setMethod('GET');

		$response = $this->httpUtil->requestURL($request);

		if($response->getHttpCode() == 200)
		{
			return $response->getContent();
		}

		return false;
	}
	
	private function reservationInternal(
			  $apiMethod
			, $terminal
			, $shop_orderid
			, $amount
			, $currency
			, $cc_num
			, $cc_expiry_year
			, $cc_expiry_month
			, $credit_card_token
			, $cvc
			, $type
			, $payment_source
			, array $customerInfo
			, array $transaction_info)
	{
		$this->checkConnection();
	
		$args = array(
				'terminal'=>$terminal,
				'shop_orderid'=>$shop_orderid,
				'amount'=>$amount,
				'currency'=>$currency,
				'cvc'=>$cvc,
				'type'=>$type,
				'payment_source'=>$payment_source
		);
		if(!is_null($credit_card_token))
		{
			$args['credit_card_token'] = $credit_card_token;
		}
		else
		{
			$args['cardnum'] = $cc_num;
			$args['emonth'] = $cc_expiry_month;
			$args['eyear'] = $cc_expiry_year;
		}

        if(!is_null($customerInfo) && is_array($customerInfo))
        {
            $this->addCustomerInfo($customerInfo, $args);
        }

        // Not needed when everyone has been upgraded to 20150428
        // ====================================================================
		foreach(array('billing_city', 'billing_region', 'billing_postal', 'billing_country', 'email', 'customer_phone', 'bank_name', 'bank_phone', 'billing_firstname', 'billing_lastname', 'billing_address') as $custField)
		{
			if(isset($customerInfo[$custField]))
			{
				$args[$custField] = $customerInfo[$custField];
			}
		}
        // ====================================================================
		if(count($transaction_info) > 0)
		{
			$args['transaction_info'] = $transaction_info;
		}
	
		return new ValitorOmniReservationResponse(
				$this->callAPIMethod(
						$apiMethod,
						$args
				)
		);
	}
	

	/**
	 * @return ValitorOmniReservationResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function reservationOfFixedAmount(
		  $terminal
		, $shop_orderid
		, $amount
		, $currency
		, $cc_num
		, $cc_expiry_year
		, $cc_expiry_month
		, $cvc
		, $payment_source
		, array $customerInfo = array()
		, array $transactionInfo = array())
	{
		return $this->reservationInternal(
				'reservationOfFixedAmountMOTO'
				, $terminal
				, $shop_orderid
				, $amount
				, $currency
				, $cc_num
				, $cc_expiry_year
				, $cc_expiry_month
				, null // $credit_card_token
				, $cvc
				, 'payment'
				, $payment_source
				, $customerInfo
				, $transactionInfo);
	}

	/**
	 * @return ValitorOmniReservationResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function reservationOfFixedAmountMOTOWithToken(
		$terminal
		, $shop_orderid
		, $amount
		, $currency
		, $credit_card_token
		, $cvc = null
		, $payment_source = 'moto'
		, array $customerInfo = array()
		, array $transactionInfo = array())
	{
		return $this->reservationInternal(
				'reservationOfFixedAmountMOTO'
				, $terminal
				, $shop_orderid
				, $amount
				, $currency
				, null
				, null
				, null
				, $credit_card_token
				, $cvc
				, 'payment'
				, $payment_source
				, $customerInfo
				, $transactionInfo);
	}

	/**
	 * @return ValitorOmniReservationResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function setupSubscription(
		$terminal
		, $shop_orderid
		, $amount
		, $currency
		, $cc_num
		, $cc_expiry_year
		, $cc_expiry_month
		, $cvc
		, $payment_source
		, array $customerInfo = array()
		, array $transactionInfo = array())
	{
		return $this->reservationInternal(
				'setupSubscription'
				, $terminal
				, $shop_orderid
				, $amount
				, $currency
				, $cc_num
				, $cc_expiry_year
				, $cc_expiry_month
				, null // $credit_card_token
				, $cvc
				, 'subscription'
				, $payment_source
				, $customerInfo
				, $transactionInfo);		
	}

	/**
	 * @return ValitorOmniReservationResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function setupSubscriptionWithToken(
		$terminal
		, $shop_orderid
		, $amount
		, $currency
		, $credit_card_token
		, $cvc = null
		, $payment_source = 'moto'
		, array $customerInfo = array()
		, array $transactionInfo = array())
	{
		return $this->reservationInternal(
			'setupSubscription'
			, $terminal
			, $shop_orderid
			, $amount
			, $currency
			, null
			, null
			, null
			, $credit_card_token
			, $cvc
			, 'subscription'
			, $payment_source
			, $customerInfo
			, $transactionInfo);
	}
	
	/**
	 * @return ValitorOmniReservationResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function verifyCard(
		$terminal
		, $shop_orderid
		, $currency
		, $cc_num
		, $cc_expiry_year
		, $cc_expiry_month
		, $cvc
		, $payment_source
		, array $customerInfo = array()
		, array $transactionInfo = array())
	{
		return $this->reservationInternal(
				'reservationOfFixedAmountMOTO'
				, $terminal
				, $shop_orderid
				, 1.00
				, $currency
				, $cc_num
				, $cc_expiry_year
				, $cc_expiry_month
				, null // $credit_card_token
				, $cvc
				, 'verifyCard'
				, $payment_source
				, $customerInfo
				, $transactionInfo);		
	}

	/**
	 * @return ValitorOmniReservationResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function verifyCardWithToken(
		$terminal
		, $shop_orderid
		, $currency
		, $credit_card_token
		, $cvc = null
		, $payment_source = 'moto'
		, array $customerInfo = array()
		, array $transactionInfo = array())
	{
		return $this->reservationInternal(
			'reservationOfFixedAmountMOTO'
			, $terminal
			, $shop_orderid
			, 1.00
			, $currency
			, null
			, null
			, null
			, $credit_card_token
			, $cvc
			, 'verifyCard'
			, $payment_source
			, $customerInfo
			, $transactionInfo);
	}
	
	
	/**
	 * @return ValitorCaptureResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function captureReservation($paymentId, $amount=null, array $orderLines=array(), $salesTax=null, $reconciliationIdentifier=null, $invoiceNumber=null)
	{
		$this->checkConnection();

		return new ValitorCaptureResponse(
			$this->callAPIMethod(
				'captureReservation',
				array(
					'transaction_id'=>$paymentId,
					'amount'=>$amount,
					'orderLines'=>$orderLines,
					'sales_tax'=>$salesTax,
					'reconciliation_identifier'=>$reconciliationIdentifier,
					'invoice_number'=>$invoiceNumber
				)
			)
		);
	}

	/**
	 * @return ValitorRefundResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function refundCapturedReservation($paymentId, $amount=null, $orderLines=null, $reconciliationIdentifier=null, $allowOverRefund=null, $invoiceNumber=null)
	{
		$this->checkConnection();

		return new ValitorRefundResponse(
			$this->callAPIMethod(
				'refundCapturedReservation',
				array(
					'transaction_id'=>$paymentId, 
					'amount'=>$amount,
					'orderLines'=>$orderLines,
					'reconciliation_identifier'=>$reconciliationIdentifier,
					'allow_over_refund'=>$allowOverRefund,
					'invoice_number'=>$invoiceNumber
				)
			)
		);
	}

	/**
	 * @param $paymentId string
	 * @param $orderLines array
	 * @return ValitorUpdateOrderResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function updateOrder($paymentId, $orderLines)
	{
		if ($orderLines == null ||  count ($orderLines) != 2)
		{
			throw new ValitorMerchantAPIException("orderLines must contain exactly two elements");
		}

		$this->checkConnection();

		return new ValitorUpdateOrderResponse(
			$this->callAPIMethod(
				'updateOrder',
				array(
					'payment_id'=>$paymentId,
					'orderLines'=>$orderLines
				)
			)
		);
	}

	/**
	 * @return ValitorReleaseResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function releaseReservation($paymentId, $amount=null)
	{
		$this->checkConnection();

		return new ValitorReleaseResponse(
			$this->callAPIMethod(
				'releaseReservation',
				array(
					'transaction_id'=>$paymentId
				)
			)
		);
	}

	/**
	 * @return ValitorGetPaymentResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function getPayment($paymentId)
	{
		$this->checkConnection();

		return new ValitorGetPaymentResponse($this->callAPIMethod(
			'payments',
			array(
				'transaction'=>$paymentId
			)
		));
	}
	
	/**
	 * @return ValitorGetTerminalsResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function getTerminals()
	{
		$this->checkConnection();

		return new ValitorGetTerminalsResponse($this->callAPIMethod('getTerminals'));
	}

	/**
	 * @return ValitorLoginResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function login()
	{
		$this->connected = false;
		
		$response = new ValitorLoginResponse($this->callAPIMethod('login'));
		
		if($response->getErrorCode() === '0')
		{
			$this->connected = true;
		}
		
		return $response;
	}
	
	/**
	 * @return ValitorCreatePaymentRequestResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function createPaymentRequest($terminal,
			$orderid,
			$amount,
			$currencyCode,
			$paymentType,
			$customerInfo = null,
			$cookie = null,
			$language = null,
			array $config = array(),
			array $transaction_info = array(),
			array $orderLines = array(),
			$accountOffer = false,
			$ccToken = null
		)
	{
		$args = array(
			'terminal'=>$terminal,
			'shop_orderid'=>$orderid,
			'amount'=>$amount,
			'currency'=>$currencyCode,
			'type'=>$paymentType
		);
		
		if(!is_null($customerInfo) && is_array($customerInfo))
		{
            $this->addCustomerInfo($customerInfo, $args);
		}
		
		if(!is_null($cookie))
		{
			$args['cookie'] = $cookie;
		}  
		if(!is_null($language))
		{
			$args['language'] = $language;
		}
		if(count($transaction_info) > 0)
		{
			$args['transaction_info'] = $transaction_info;
		}
		if(count($orderLines) > 0)
		{
			$args['orderLines'] = $orderLines;
		}
		if(in_array($accountOffer, array("required", "disabled")))
		{
			$args['account_offer'] = $accountOffer;
		}
        if(!is_null($ccToken))
        {
            $args['ccToken'] = $ccToken;
        }

		$args['config'] = $config;
		
		return new ValitorCreatePaymentRequestResponse($this->callAPIMethod('createPaymentRequest', $args));
	}

	public function createInvoiceReservation($terminal,
											 $shop_orderid,
											 $amount,
											 $currencyCode,
											 $paymentType = null,
											 $customerInfo = null,
											 array $transaction_info = array(),
											 $accountNumber = null,
											 $bankCode = null,
											 $fraud_service = null,
											 $payment_source = null,
											 array $orderLines = array(),
											 $organisationNumber = null,
											 $personalIdentifyNumber = null,
											 $birthDate = null)
	{
		$args = array(
			'terminal' => $terminal,
			'shop_orderid' => $shop_orderid,
			'amount' => $amount,
			'currency' => $currencyCode
		);

		if(!is_null($paymentType))
		{
			$args['type'] = $paymentType;
		}
		if(!is_null($customerInfo) && is_array($customerInfo))
		{
			$this->addCustomerInfo($customerInfo, $args); // just checks and saves $customerInfo inside $args
		}
		if(count($transaction_info) > 0) {
			$args['transaction_info'] = $transaction_info;
		}
		if(!is_null($accountNumber))
		{
			$args['accountNumber'] = $accountNumber;
		}
		if(!is_null($bankCode))
		{
			$args['bankCode'] = $bankCode;
		}
		if(!is_null($fraud_service))
		{
			$args['fraud_service'] = $fraud_service;
		}
		if(!is_null($payment_source))
		{
			$args['payment_source'] = $payment_source;
		}
		if(count($orderLines) > 0) {
			$args['orderLines'] = $orderLines;
		}
		if(!is_null($organisationNumber)) {
			$args['organisationNumber'] = $organisationNumber;
		}
		if(!is_null($personalIdentifyNumber)) {
			$args['personalIdentifyNumber'] = $personalIdentifyNumber;
		}
		if(!is_null($birthDate)) {
			$args['birthDate'] = $birthDate;
		}

		return new ValitorCreateInvoiceReservationResponse($this->callAPIMethod('createInvoiceReservation', $args));

	}

	public function reservation($terminal,
								$shop_orderid,
								$amount,
								$currencyCode,
								$creditCardToken = null,
								$pan = null,
								$expiryMonth = null,
								$expiryYear = null,
								$cvc = null,
								array $transaction_info = array(),
								$paymentType = null,
								$paymentSource = null,
								$fraudService = null,
								$surcharge = null,
								$customerCreatedDate = null,
								$shippingMethod = null,
								$customerInfo = null,
								array $orderLines = array()
	)
	{
		$args = array(
			'terminal' => $terminal,
			'shop_orderid' => $shop_orderid,
			'amount' => $amount,
			'currency' => $currencyCode
		);

		if(!is_null($creditCardToken))
		{
			$args['credit_card_token'] = $creditCardToken;
		}
		if(!is_null($pan))
		{
			$args['cardnum'] = $pan;
		}
		if(!is_null($expiryMonth))
		{
			$args['emonth'] = $expiryMonth;
		}
		if(!is_null($expiryYear))
		{
			$args['eyear'] = $expiryYear;
		}
		if(!is_null($cvc))
		{
			$args['cvc'] = $cvc;
		}
		if(count($transaction_info) > 0) {
			$args['transaction_info'] = $transaction_info;
		}
		if(!is_null($paymentType))
		{
			$args['type'] = $paymentType;
		}
		if(!is_null($paymentSource))
		{
			$args['payment_source'] = $paymentSource;
		}
		if(!is_null($fraudService))
		{
			$args['fraud_service'] = $fraudService;
		}
		if(!is_null($surcharge))
		{
			$args['surcharge'] = $surcharge;
		}
		if(!is_null($customerCreatedDate))
		{
			$args['customer_created_date'] = $customerCreatedDate;
		}
		if(!is_null($shippingMethod))
		{
			$args['shipping_method'] = $shippingMethod;
		}
		if(!is_null($customerInfo) && is_array($customerInfo))
		{
			$this->addCustomerInfo($customerInfo, $args); // just checks and saves $customerInfo inside $args
		}
		if(count($orderLines) > 0) {
			$args['orderLines'] = $orderLines;
		}

		return new ValitorReservationResponse($this->callAPIMethod('reservation', $args));

	}

	/**
	 * @return ValitorCaptureRecurringResponse
	 * @deprecated - use chargeSubscription instead.
	 * @throws ValitorMerchantAPIException
	 */
	public function captureRecurring($subscriptionId, $amount=null)
	{
		return $this->chargeSubscription($subscriptionId, $amount);
	}

	/**
	 * @return ValitorCaptureRecurringResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function chargeSubscriptionWithReconciliationIdentifier($subscriptionId, $reconciliationIdentifier, $amount=null)
	{
		$this->checkConnection();

		return new ValitorCaptureRecurringResponse(
			$this->callAPIMethod(
				'chargeSubscription',
				array(
					'transaction_id'=>$subscriptionId,
					'amount'=>$amount,
					'reconciliation_identifier'=>$reconciliationIdentifier,
				)
			)
		);
	}

	public function chargeSubscription($subscriptionId,$amount=null)
	{
		return $this->chargeSubscriptionWithReconciliationIdentifier($subscriptionId, null, $amount);
	}
	
	/**
	 * @return ValitorPreauthRecurringResponse
	 * @deprecated - use reserveSubscriptionCharge instead
	 * @throws ValitorMerchantAPIException
	 */
	public function preauthRecurring($subscriptionId, $amount=null)
	{
		return $this->reserveSubscriptionCharge($subscriptionId, $amount);
	}
	
	
	/**
	 * @return ValitorPreauthRecurringResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function reserveSubscriptionCharge($subscriptionId, $amount=null)
	{
		$this->checkConnection();

		return new ValitorPreauthRecurringResponse(
			$this->callAPIMethod(
				'reserveSubscriptionCharge',
				array(
					'transaction_id'=>$subscriptionId, 
					'amount'=>$amount,
				)
			)
		);
	}

	/**
	 * @return ValitorCalculateSurchargeResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function calculateSurcharge($terminal, $cardToken, $amount, $currency)
	{
		$this->checkConnection();
	
		return new ValitorCalculateSurchargeResponse(
				$this->callAPIMethod(
						'calculateSurcharge',
						array(
								'terminal'=>$terminal,
								'credit_card_token'=>$cardToken,
								'amount'=>$amount,
								'currency'=>$currency,
						)
				)
		);
	}
	
	/**
	 * @return ValitorCalculateSurchargeResponse
	 * @throws ValitorMerchantAPIException
	 */
	public function calculateSurchargeForSubscription($subscriptionId, $amount)
	{
		$this->checkConnection();
	
		return new ValitorCalculateSurchargeResponse(
				$this->callAPIMethod(
						'calculateSurcharge',
						array(
								'payment_id'=>$subscriptionId,
								'amount'=>$amount,
						)
				)
		);
	}

	/**
	 * @return string|boolean
	 * @throws ValitorMerchantAPIException
	 */
	public function getCustomReport($args)
	{
		$this->checkConnection();
		$response = $this->callAPIMethod('getCustomReport', $args);
		return $response;
	}

	/**
	 * @return string|boolean
	 * @throws ValitorMerchantAPIException
	 */
	public function getTransactions(ValitorAPITransactionsRequest $transactionsRequest)
	{
		$this->checkConnection();
		return $this->callAPIMethod('transactions', $transactionsRequest->asArray());
	}

    /**
     * @param $customerInfo
     * @param $args
     * @throws ValitorMerchantAPIException
     */
    private function addCustomerInfo($customerInfo, &$args)
    {
        $errors = array();

        foreach ($customerInfo as $customerInfoKey => $customerInfoValue) {
            if (is_array($customerInfo[$customerInfoKey])) {
                $errors[] = "customer_info[$customerInfoKey] is not expected to be an array";
            }
        }
        if (count($errors) > 0) {
            throw new ValitorMerchantAPIException("Failed to create customer_info variable: \n" . print_r($errors, true));
        }
        $args['customer_info'] = $customerInfo;
    }
}
