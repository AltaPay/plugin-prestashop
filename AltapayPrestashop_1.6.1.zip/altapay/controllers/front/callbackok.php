<?php

require_once(_PS_MODULE_DIR_.'/altapay/lib/pensio/pensio-php-api/lib/PensioCallbackHandler.class.php');
require_once(_PS_MODULE_DIR_.'/altapay/helpers.php');

class AltaPayCallbackokModuleFrontController extends ModuleFrontController
{

	// restrict access to this page
	public function checkAccess()
	{
		if (!$this->module->checkAccess())
		{
			Tools::redirect($this->context->link->getPageLink('404'));
			return false;
		}
		return true;
	}

	public function postProcess()
	{

		try{
			$xml = Tools::getValue('xml');
			$callbackHandler = new PensioCallbackHandler();
			$response = $callbackHandler->parseXmlResponse($xml);

			$shopOrderId = $response->getPrimaryPayment()->getShopOrderId();

			//this lock prevents orders to be created twice.
			$fp = fopen('lock.txt', 'r');
			flock($fp, LOCK_EX);

			// load the cart
			$cart = get_cart_from_unique_id($shopOrderId);
			if(!Validate::isLoadedObject($cart)) {
				$this->unlock($fp);
				die('Could not load cart - exiting');
			}

			// load the customer
			$customer = new Customer((int)$cart->id_customer);

			// check if an order already exists
			$order = get_order_from_unique_id($shopOrderId);
			if(Validate::isLoadedObject($order)) {
				// an order has already been created from this cart - redirect
				Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
			}

			// handle success
			if ($response->wasSuccessful())
			{
				$order_status=(int)Configuration::get('PS_OS_PAYMENT');

				$paymentType=$response->getPrimaryPayment()->getAuthType();
				$amount_paid=$response->getPrimaryPayment()->getCapturedAmount();
				$currency_paid=Currency::getIdByIsoCode($response->getPrimaryPayment()->getCurrency());
				//if payment type is 'payment' funds have not yet been captured, so Pensio returns zero as the captured amount.  Therefore we assume full payment has been authorized.
				if ($paymentType=='payment')
				{
					$amount_paid = $cart->getOrderTotal(true, Cart::BOTH);
					$currency_paid = new Currency($cart->id_currency);
				}

				//determine payment method for display
				$paymentMethod = determine_payment_method_for_display($response);

				//create an order with 'payment accepted' status
				$this->module->validateOrder($cart->id, $order_status, $amount_paid, $paymentMethod, NULL, NULL, (int)$currency_paid->id, false, $customer->secure_key);

				// log order
				$current_order = new Order((int)$this->module->currentOrder);
				create_altapay_order($response, $current_order);
				$this->unlock($fp);

				Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
			}
			else
			{
				//unexpected scenario
				Logger::addLog('Unexpected scenario: Callback ok was received but payment was not successful' , 3, '1004', $this->module->name, $this->module->id, true);
				echo $this->module->l('This payment method is not available 1004.', 'callbackok');

				//redirect user back to checkout payment step, assume a failure occured creating the URL until a payment url is received
				$controller = Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc.php' : 'order.php';
				$redirect=$this->context->link->getPageLink($controller, true, NULL, "step=3&altapay_unavailable=1").'#altapay_unavailable';
				$this->unlock($fp);
				Tools::redirect($redirect);

			}

		} finally {
			$this->unlock($fp);
		}

	}

	public function unlock($fileOpen)
	{
		flock($fileOpen, LOCK_UN);
		fclose($fileOpen);
	}

}
