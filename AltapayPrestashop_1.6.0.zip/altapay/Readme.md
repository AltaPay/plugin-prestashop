Tested with Prestashop 1.6.x

== Changelog ==

* 1.6.0


    ** PHP SDK updated

* 1.5.1


    ** Added cart information to the payment view

* 1.5.0


    ** Imported PHP Client Library via Composer