<?php

require_once(_PS_MODULE_DIR_.'/altapay/lib/pensio/pensio-php-api/lib/PensioMerchantAPI.class.php');

class AltaPayPaymentModuleFrontController extends ModuleFrontController
{
	public $ssl = true;

	public function initContent()
	{
		$this->display_column_left = false;
		parent::initContent();

		$cart = $this->context->cart;
		if (!$this->module->checkCurrency($cart))
			Tools::redirect('index.php?controller=order');

		//redirect user back to checkout payment step, assume a failure occured creating the URL until a payment url is received
		$controller = Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc.php' : 'order.php';		
		$payment_form_url=$this->context->link->getPageLink($controller, true, NULL, "step=3&altapay_unavailable=1").'#altapay_unavailable';

		$payment_method=Tools::getValue('method', false);		
		$result=$this->module->createTransaction($payment_method);

		if ($result['success'])
		{
			$payment_form_url=$result['payment_form_url'];

			//insert into transaction log
			$sql='INSERT INTO `'._DB_PREFIX_.'altapay_transaction` 
				(id_cart, payment_form_url, unique_id, amount, date_add) VALUES '.
				"('".$cart->id."', '".$payment_form_url."', '".$result['uniqueid']."', '".$result['amount']."', '".time()."')";
			Db::getInstance()->Execute($sql);

			//redirect user to payment form url
			Tools::redirect($payment_form_url);
		}
		else  
		{
			//redirect user back to checkout with generic error
			Tools::redirect($payment_form_url);
		}
	}
}

