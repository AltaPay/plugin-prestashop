<?php

class AltaPayCallbackformModuleFrontController extends ModuleFrontController
{
	// restrict access to this page
	public function checkAccess()
	{
		if (!$this->module->checkAccess())
		{die();
			Tools::redirect($this->context->link->getPageLink('404'));
			return false;
		}
		return true;
	}

	// add media
	public function setMedia() {
		parent::setMedia();
		$this->addCSS(($this->module->getPathUri()).'css/altapay.css', 'all');
	}

	// handle POST
	public function postProcess()
	{
		$this->context->smarty->assign('pathUri', $this->module->getPathUri());
		$this->setTemplate('payment_form.tpl');
	}
}
