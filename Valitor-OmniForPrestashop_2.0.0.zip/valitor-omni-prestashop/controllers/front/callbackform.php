<?php
/**
 * NOTICE OF LICENSE
 *
 * This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * @author Simion Zafiu <simion.zafiu@valitor.com>
 * @copyright Copyright (C) 2019 Valitor  (https://valitor.com)
 * @license GNU General Public License v3.0 <http://www.gnu.org/licenses/gpl-3.0.html>
 */

require_once(_PS_MODULE_DIR_.'/valitor/lib/valitor/valitor-php-sdk/lib/ValitorCallbackHandler.class.php');
require_once(_PS_MODULE_DIR_.'/valitor/helpers.php');

class ValitorCallbackformModuleFrontController extends ModuleFrontController
{
    // add media
    public function setMedia()
    {
        parent::setMedia();
        $this->addCSS(($this->module->getPathUri()).'css/valitor.css', 'all');
        $this->addCSS(($this->module->getPathUri()).'css/custom_css.css', 'all');
    }

    // handle POST
    public function postProcess()
    {
        //Different conventions of assigning details for Version 1.6 and 1.7 respectively
        if (_PS_VERSION_ >= '1.7.0.0') {
            $cart = $this->context->cart;
            $this->context->smarty->assign('pathUri', $this->module->getPathUri());
            $this->context->smarty->assign('summarydetails', $cart->getSummaryDetails());
            $this->context->smarty->assign('products', $cart->getProducts());
            $this->setTemplate('module:valitor/views/templates/front/payment_form17.tpl');
        } else {
            $this->context->smarty->assign('pathUri', $this->module->getPathUri());
            $this->setTemplate('payment_form.tpl');
        }
    }
}
