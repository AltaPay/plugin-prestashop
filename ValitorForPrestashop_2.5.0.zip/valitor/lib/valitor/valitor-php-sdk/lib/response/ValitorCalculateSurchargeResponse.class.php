<?php

if(!defined('VALITOR_API_ROOT'))
{
	define('VALITOR_API_ROOT',dirname(__DIR__));
}

require_once(VALITOR_API_ROOT.'/response/ValitorAbstractResponse.class.php');
require_once(VALITOR_API_ROOT.'/response/ValitorTerminal.class.php');

class ValitorCalculateSurchargeResponse extends ValitorAbstractResponse
{
	private $result;
	private $surchargeAmount = array();
	
	public function __construct(SimpleXmlElement $xml)
	{
		parent::__construct($xml);
		
		if($this->getErrorCode() === '0')
		{
			$this->result = (string)$xml->Body->Result;
			$this->surchargeAmount = (string)$xml->Body->SurchageAmount;
		}
	}
	
	public function getSurchargeAmount()
	{
		return $this->surchargeAmount;
	}
	
	public function wasSuccessful()
	{
		return $this->result === 'Success';
	}
}