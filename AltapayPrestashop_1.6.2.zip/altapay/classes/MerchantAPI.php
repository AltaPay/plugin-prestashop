<?php
require_once(_PS_MODULE_DIR_.'/altapay/lib/pensio/pensio-php-sdk/lib/PensioMerchantAPI.class.php');

/**
 * Wrapper for interacting with AltaPay merchant API
 *
 * @author Ulrik Andersen ulrik.and@gmail.com
 */
class MerchantAPI 
{
	/**
	 * @var PensioMerchantAPI
	 */
	private $api;
    private $api_url;
    private $api_username;
    private $api_password;
    
    public function __construct() 
    {
    }
    
    public function init($api_url, $api_username, $api_password) 
    {
        $this->api_url = $api_url;
        $this->api_username = $api_username;
        $this->api_password = $api_password;
        $this->validateConfiguration();
    }

	public function getPaymentDetails($paymentId)
	{
		$response = $this->api->getPayment($paymentId);

		if(is_null($response)) {
			throw new Exception("Could not get payment details of payment ".$paymentId);
		}

		return $response->getPrimaryPayment();
	}

    public function captureAmount($paymentId, $amount=0, $orderLines = array())
    {
        $response = $this->api->captureReservation($paymentId, $amount, $orderLines);

        if(!$response->wasSuccessful()) {
            throw new Exception($response->getMerchantErrorMessage());
        }

        return $response;
    }

	public function refundAmount($paymentId, $amount=0, $orderLines=array())
	{
		$response = $this->api->refundCapturedReservation($paymentId, $amount, $orderLines);

		if(!$response->wasSuccessful()) {
			throw new Exception($response->getMerchantErrorMessage());
		}

		return $response;
	}

    public function release($paymentId)
    {
        $response = $this->api->releaseReservation($paymentId);

        if(!$response->wasSuccessful()) {
            throw new Exception($response->getMerchantErrorMessage());
        }

        return $response;
    }

    private function validateConfiguration()
    {
        if(empty($this->api_url) ||
            empty($this->api_username) ||
            empty($this->api_password))
        {
            throw new Exception('URL, username or password missing');
        }

        $this->api = new PensioMerchantAPI($this->api_url, $this->api_username,
                $this->api_password, null);
        $response = $this->api->login();
        if(!$response->wasSuccessful()) {
            throw new Exception("Could not login to the Merchant API: ".
                    $response->getErrorMessage(), $response->getErrorCode() );
        }
    }

}
