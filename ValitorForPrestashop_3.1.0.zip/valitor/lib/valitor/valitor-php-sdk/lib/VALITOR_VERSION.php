<?php
define('VALITOR_VERSION', 'PHPSDK/2.1.0');