<?php

require_once(_PS_MODULE_DIR_.'/altapay/lib/pensio/pensio-php-api/lib/PensioCallbackHandler.class.php');
require_once(_PS_MODULE_DIR_.'/altapay/helpers.php');

class AltaPayCallbackopenModuleFrontController extends ModuleFrontController
{

	//restrict access to this page
	public function checkAccess()
	{
		if (!$this->module->checkAccess())
		{
			Tools::redirect($this->context->link->getPageLink('404'));
			return false;
		}
		return true;
	}

	/**
	 * If the payment state is "open", the module will convert the shopping cart to an 
	 * order using a the defined "Awaiting Payment Processing" order status. The module 
	 * will display a message to the customer stating that an order has been created but 
	 * is awaiting payment processing.
	 * AltaPay will send a notification to the "open" callback URL when the payment moves 
	 * to "success" or "failure". The module will then update the order status to either 
	 * "Payment Accepted" or "Payment Error". 
	 */
	public function postProcess()
	{
		$xml = Tools::getValue('xml');
		$callbackHandler = new PensioCallbackHandler();
		$response = $callbackHandler->parseXmlResponse($xml);

		$shopOrderId = $response->getPrimaryPayment()->getShopOrderId();

		// load the cart
		$cart = get_cart_from_unique_id($shopOrderId);
		if(!Validate::isLoadedObject($cart)) {
			die('Could not load cart - exiting');
		}

		// load the customer
		$customer = new Customer((int)$cart->id_customer);

		// amount paid is returned as 0, so we use cart amount instead
		$amount_paid = $cart->getOrderTotal(true, Cart::BOTH);
		$currency_paid = new Currency($cart->id_currency);
                
        // determine payment method for display
        $paymentMethod = determine_payment_method_for_display($response);

        // create order
		$this->module->validateOrder($cart->id, Configuration::get('ALTAPAY_OS_PENDING'), $amount_paid, $paymentMethod, NULL, NULL, (int)$currency_paid->id, false, $customer->secure_key);

		// log order
		$current_order = new Order((int)$this->module->currentOrder);
		create_altapay_order($response, $current_order, 'open');

		Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
	}

}
