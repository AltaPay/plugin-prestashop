Altapay - PHP SDK
=================

== Change log ==

** Version 1.0.6

    * ChargeSubscription can take reconciliationIdentifier

** Version 1.0.5

    * Expose CreatedDate and UpdatedDate for payments

** Version 1.0.4

    * New child element [IsTokenized] in Transaction

** Version 1.0.3

    * Bugfix: Typo in package name
    * Improvements: Add composer.lock

** Version 1.0.2

    * Bugfix: PensioCallbackHandler - xml body response with error and Transactions element

** Version 1.0.1

    * Bugfix: PensioCallbackHandler - xml body response without Transaction element

** Version 1.0.0

    * Set the base for the version number

** Version 0.1.0

    * New child element [PaymentSource] in Transaction

** Version 0.0.1

    * Created the change log 