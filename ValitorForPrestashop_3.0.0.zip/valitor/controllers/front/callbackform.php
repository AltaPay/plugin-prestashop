<?php
/**
 * Valitor module for Prestashop
 *
 * Copyright © 2020 Valitor. All rights reserved.
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

require_once(_PS_MODULE_DIR_.'/valitor/lib/valitor/valitor-php-sdk/lib/ValitorCallbackHandler.class.php');
require_once(_PS_MODULE_DIR_.'/valitor/helpers.php');

class ValitorCallbackformModuleFrontController extends ModuleFrontController
{
    /**
     * Method to add external assets
     */
    public function setMedia()
    {
        parent::setMedia();
        $this->addCSS(($this->module->getPathUri()).'css/valitor.css', 'all');
        $this->addCSS(($this->module->getPathUri()).'css/custom_css.css', 'all');
    }


    /**
     * Method to follow when callback form is being requested
     */
    public function postProcess()
    {
        $css_dir = null;
        //Different conventions of assigning details for Version 1.6 and 1.7 respectively
        if (_PS_VERSION_ >= '1.7.0.0') {
            $cart = $this->context->cart;
            $this->context->smarty->assign('pathUri', $this->module->getPathUri());
            $this->context->smarty->assign('summarydetails', $cart->getSummaryDetails());
            $this->context->smarty->assign('products', $cart->getProducts());
            $this->context->smarty->assign('css_dir', $css_dir);
            $this->setTemplate('module:valitor/views/templates/front/payment_form17.tpl');
        } else {
            $this->context->smarty->assign('pathUri', $this->module->getPathUri());
            $this->setTemplate('payment_form.tpl');
        }
    }
}
