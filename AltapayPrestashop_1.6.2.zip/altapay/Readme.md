# Altapay Prestashop plugin
http://git.mars.pensio.com/aux/PrestaShop-plugin

## Supported versions
Prestashop 1.6.x

## Generating the zip archive

 To create the bundle, execute the build script build.xml with ant:
 
	$ ant -buildfile build.xml
	
located in the source code directory. This script will create the file /tmp/AltapayPrestashop_LastGitTagAsVersion.zip, that can be sent to the merchants.

### OBS:
Follow exactly the same order as are the steps below mentioned:
* update the “Readme.md” file;
* commit + push the final changes;
* create + push the tag name with the newest version mentioned in the Changelog list.


## Changelog

* 1.6.2


    ** Set the min supported version to 1.6.0.5
    ** Set the max supported version to 1.6.1.23
    ** PHP SDK reference updated

* 1.6.1


    ** Fix issue with multiple orders and ViaBill
    ** PHP SDK updated

* 1.6.0


    ** PHP SDK updated

* 1.5.1


    ** Added cart information to the payment view

* 1.5.0


    ** Imported PHP Client Library via Composer