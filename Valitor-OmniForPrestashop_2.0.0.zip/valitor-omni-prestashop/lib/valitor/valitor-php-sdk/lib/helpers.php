<?php

spl_autoload_register('autoLoader');

function autoLoader($class)
{
	$previousDirectory = dirname(__DIR__);
	include $previousDirectory.'/lib'.'/'.$class.'.class.php';
	include $previousDirectory.'/lib/response'.'/'.$class.'.class.php';
	include $previousDirectory.'/lib/request'.'/'.$class.'.class.php';
	include $previousDirectory.'/lib/http'.'/'.$class.'.class.php';
	include $previousDirectory.'/lib/exceptions'.'/'.$class.'.class.php';
	include $previousDirectory.'/lib/VALITOR_VERSION.php';
}

