<?php

require_once(_PS_MODULE_DIR_.'/altapay/lib/pensio/pensio-php-sdk/lib/PensioCallbackHandler.class.php');
require_once(_PS_MODULE_DIR_.'/altapay/helpers.php');

class AltaPayCallbackfailModuleFrontController extends ModuleFrontController
{

	// restrict access to this page
	public function checkAccess()
	{
		if (!$this->module->checkAccess())
		{
			Tools::redirect($this->context->link->getPageLink('404'));
			return false;
		}
		return true;
	}

	public function postProcess()
	{
		$xml=Tools::getValue('xml');
		$callbackHandler = new PensioCallbackHandler();
		$response = $callbackHandler->parseXmlResponse($xml);

		$shopOrderId = $response->getPrimaryPayment()->getShopOrderId();

		// load the cart
		$cart = get_cart_from_unique_id($shopOrderId);
		if(!Validate::isLoadedObject($cart)) {
			die('Could not load cart - exiting');
		}

		$status = Tools::getValue('payment_status');
		if ($status=='epayment_cancelled')
		{
			$unique_id=Tools::getValue('shop_orderid');
			// updated transaction record to cancel
			Db::getInstance()->Execute('UPDATE `'._DB_PREFIX_.'altapay_transaction` set `is_cancelled`=1 WHERE `unique_id`=\''.pSQL($unique_id).'\'');

			// redirect back to either standard or quick checkout process
			$controller = Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc.php' : 'order.php';
			$location = $this->context->link->getPageLink($controller).(strpos($controller, '?') !== false ? '&' : '?').'altapay_cancel=1&isPaymentStep=true&step=3#altapay_cancel';
			Tools::redirectLink($location);
		}
		else 
		{
			$merchantErrorMessage = $response->getMerchantErrorMessage();
			Logger::addLog('Payment failure for cart '.$cart->id.'. Error Message: '.$merchantErrorMessage, 3, 2001, $this->module->name, $this->module->id, true);

			// redirect user back to checkout payment step, assume a failure occured creating the URL until a payment url is received
			$controller = Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc.php' : 'order.php';		
			$payment_form_url=$this->context->link->getPageLink($controller, true, NULL, "step=3&altapay_unavailable=1");

			$this->context->smarty->assign(array(
				'errorText' => $response->getCardHolderErrorMessage(),
				'unique_id' => $response->getPrimaryPayment()->getShopOrderId(),
				'payment_id' => $response->getPrimaryPayment()->getId(),
				'this_path' => $this->module->getPathUri(),
				'this_path_altapay' => $this->module->getPathUri(),
				'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->module->name.'/',
			));

			$this->setTemplate('payment_error.tpl');	
		}
	}
}
