<?php
define('ALTAPAY_VERSION', 'PHPSDK/2.1.0');
