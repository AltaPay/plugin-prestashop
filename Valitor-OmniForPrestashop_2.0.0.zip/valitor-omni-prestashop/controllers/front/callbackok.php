<?php
/**
 * NOTICE OF LICENSE
 *
 * This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * @author Simion Zafiu <simion.zafiu@valitor.com>
 * @copyright Copyright (C) 2019 Valitor  (https://valitor.com)
 * @license GNU General Public License v3.0 <http://www.gnu.org/licenses/gpl-3.0.html>
 */

require_once(_PS_MODULE_DIR_.'/valitor/lib/valitor/valitor-php-sdk/lib/ValitorCallbackHandler.class.php');
require_once(_PS_MODULE_DIR_.'/valitor/helpers.php');

class ValitorCallbackokModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        try {
            $xml = Tools::getValue('xml');
            $callbackHandler = new ValitorCallbackHandler();
            $response = $callbackHandler->parseXmlResponse($xml);

            $shopOrderId = $response->getPrimaryPayment()->getShopOrderId();

            
            //this lock prevents orders to be created twice.
            $fp = fopen('lock.txt', 'r');
            flock($fp, LOCK_EX);

            // load the cart
            $cart = get_cart_from_unique_id($shopOrderId);
            if (!Validate::isLoadedObject($cart)) {
                $this->unlock($fp);
                die('Could not load cart - exiting');
            }

            // load the customer
            $customer = new Customer((int)$cart->id_customer);

            // check if an order already exists
            $order = get_order_from_unique_id($shopOrderId);
            if (Validate::isLoadedObject($order)) {
                // an order has already been created from this cart - redirect
                
                //Tools::redirect('index.php?controller=order-detail&id_order='.$this->module->currentOrder);
                Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='
                .$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
            }

            // handle success
            if ($response->wasSuccessful()) {
                $order_status=(int)Configuration::get('PS_OS_PAYMENT');
                
                $paymentType=$response->getPrimaryPayment()->getAuthType();
                $amount_paid=$response->getPrimaryPayment()->getCapturedAmount();
                $currency_paid=Currency::getIdByIsoCode($response->getPrimaryPayment()->getCurrency());
                /*if payment type is 'payment' funds have not yet been captured,
                so Valitor returns zero as the captured amount. Therefore we assume full payment has been authorized.*/
                if ($paymentType=='payment') {
                    $amount_paid = $cart->getOrderTotal(true, Cart::BOTH);
                    $currency_paid = new Currency($cart->id_currency);
                }

                //determine payment method for display
                $paymentMethod = determine_payment_method_for_display($response);

                //create an order with 'payment accepted' status
                $cpId = (int)$currency_paid->id;
                $cSk = $customer->secure_key;
                $cId = $cart->id;
                $pMe = $paymentMethod;
                $this->module->validateOrder($cId, $order_status, $amount_paid, $pMe, null, null, $cpId, false, $cSk);

                // log order
                $current_order = new Order((int)$this->module->currentOrder);
                create_valitor_order($response, $current_order);
                $this->unlock($fp);
                
                Tools::redirect('index.php?controller=order-detail&id_order='.$this->module->currentOrder);
            } else {
                //unexpected scenario
                $mNa = $this->module->name;
                $mId = $this->module->id;
                Logger::addLog('Callback ok received but payment was unsuccessful', 3, '1004', $mNa, $mId, true);
                echo $this->module->l('This payment method is not available 1004.', 'callbackok');

                /*redirect user back to checkout payment step,
                assume a failure occured creating the URL until a payment url is received*/
                $controller = Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc.php' : 'order.php';
                $as = $this->context->link;
                $con = $controller;
                $redirect = $as->getPageLink($con, true, null, "step=3&valitor_unavailable=1").'#valitor_unavailable';
                $this->unlock($fp);
                Tools::redirect($redirect);
            }
        } finally {
            $this->unlock($fp);
        }
    }

    public function unlock($fileOpen)
    {
        flock($fileOpen, LOCK_UN);
        fclose($fileOpen);
    }
}
