<?php

class ValitorMerchantAPIException extends Exception
{
    
}