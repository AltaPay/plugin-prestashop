<?php

class AltaPayCallbackredirectModuleFrontController extends ModuleFrontController
{

	// restrict access to this page
	public function checkAccess()
	{
		if (!$this->module->checkAccess())
		{die();
			Tools::redirect($this->context->link->getPageLink('404'));
			return false;
		}
		return true;
	}

	// handle POST
	public function postProcess()
	{
		$this->setTemplate('payment_redirect.tpl');
	}

}
