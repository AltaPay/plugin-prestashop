<?php
/**
 * Valitor module for Prestashop
 *
 * Copyright © 2020 Valitor. All rights reserved.
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

require_once(_PS_MODULE_DIR_.'/valitor/lib/valitor/valitor-php-sdk/lib/ValitorMerchantAPI.class.php');

class VALITORPaymentModuleFrontController extends ModuleFrontController
{
    public $ssl = true;

    /**
     * Method to follow when payment is being initiated with payment method
     */
    public function initContent()
    {
        $this->display_column_left = false;
        parent::initContent();
        $savedCreditCard = null;

        $cart = $this->context->cart;
        if (!$this->module->checkCurrency($cart)) {
            Tools::redirect('index.php?controller=order');
        }

        /*redirect user back to checkout payment step,
        assume a failure occured creating the URL until a payment url is received*/
        $controller = Configuration::get('PS_ORDER_PROCESS_TYPE') ? 'order-opc.php' : 'order.php';
        $payment_form_url=$this->context->link->getPageLink($controller, true, null, "step=3&valitor_unavailable=1").
        '#valitor_unavailable';

        $payment_method=Tools::getValue('method', false);

        if(isset($_COOKIE['selectedCreditCard'])) {
            $savedCreditCard = $_COOKIE['selectedCreditCard'];
            unset($_COOKIE['selectedCreditCard']);
            setcookie('selectedCreditCard', null, -1, '/');
        } else {
            unset($_COOKIE['selectedCreditCard']);
            setcookie('selectedCreditCard', null, -1, '/');
        }

        $result=$this->module->createTransaction($payment_method, $savedCreditCard);

        if ($result['success']) {
            $payment_form_url=$result['payment_form_url'];

            //insert into transaction log
            $sql='INSERT INTO `'._DB_PREFIX_.'valitor_transaction` 
				(id_cart, payment_form_url, unique_id, amount, date_add) VALUES '.
                "('".$cart->id."', '".$payment_form_url."', '".$result['uniqueid']."', '"
                .$result['amount']."', '".time()."')";
            Db::getInstance()->Execute($sql);

            //redirect user to payment form url
            Tools::redirect($payment_form_url);
        } else {
            //redirect user back to checkout with generic error
            Tools::redirect($payment_form_url);
        }
    }
}
