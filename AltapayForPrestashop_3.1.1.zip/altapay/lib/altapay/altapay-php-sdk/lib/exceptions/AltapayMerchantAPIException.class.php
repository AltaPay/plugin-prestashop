<?php

class AltapayMerchantAPIException extends Exception
{
    
}