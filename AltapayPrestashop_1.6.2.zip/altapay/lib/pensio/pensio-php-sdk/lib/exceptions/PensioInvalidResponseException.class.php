<?php

class PensioInvalidResponseException extends PensioMerchantAPIException
{
	
}