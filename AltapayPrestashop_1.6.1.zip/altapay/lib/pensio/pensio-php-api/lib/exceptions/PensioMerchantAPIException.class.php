<?php

class PensioMerchantAPIException extends Exception
{
	
}