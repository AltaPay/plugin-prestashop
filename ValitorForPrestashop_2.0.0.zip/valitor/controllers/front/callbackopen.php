<?php
/**
 * NOTICE OF LICENSE
 *
 * This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * @author Simion Zafiu <simion.zafiu@valitor.com>
 * @copyright Copyright (C) 2019 Valitor  (https://valitor.com)
 * @license GNU General Public License v3.0 <http://www.gnu.org/licenses/gpl-3.0.html>
 */

require_once(_PS_MODULE_DIR_.'/valitor/lib/valitor/valitor-php-sdk/lib/ValitorCallbackHandler.class.php');
require_once(_PS_MODULE_DIR_.'/valitor/helpers.php');

class ValitorCallbackopenModuleFrontController extends ModuleFrontController
{

    /**
     * If the payment state is "open", the module will convert the shopping cart to an
     * order using a the defined "Awaiting Payment Processing" order status. The module
     * will display a message to the customer stating that an order has been created but
     * is awaiting payment processing.
     * VALITOR will send a notification to the "open" callback URL when the payment moves
     * to "success" or "failure". The module will then update the order status to either
     * "Payment Accepted" or "Payment Error".
     */
    public function postProcess()
    {
        $xml = Tools::getValue('xml');
        $callbackHandler = new ValitorCallbackHandler();
        $response = $callbackHandler->parseXmlResponse($xml);

        $shopOrderId = $response->getPrimaryPayment()->getShopOrderId();

        // load the cart
        $cart = get_cart_from_unique_id($shopOrderId);
        if (!Validate::isLoadedObject($cart)) {
            die('Could not load cart - exiting');
        }

        // load the customer
        $customer = new Customer((int)$cart->id_customer);

        // amount paid is returned as 0, so we use cart amount instead
        $amount_paid = $cart->getOrderTotal(true, Cart::BOTH);
        $currency_paid = new Currency($cart->id_currency);
                
        // determine payment method for display
        $paymentMethod = determine_payment_method_for_display($response);

        // create order
        $confOs = Configuration::get('VALITOR_OS_PENDING');
        $curPaid = (int)$currency_paid->id;
        $curSk = $customer->secure_key;
        $cId = $cart->id;
        $this->module->validateOrder($cId, $confOs, $amount_paid, $paymentMethod, null, null, $curPaid, false, $curSk);

        // log order
        $current_order = new Order((int)$this->module->currentOrder);
        create_valitor_order($response, $current_order, 'open');

        $curOr = $this->module->currentOrder;
        $mId = $this->module->id;
        $confOr = 'index.php?controller=order-confirmation&id_cart=';
        Tools::redirect($confOr.$cId.'&id_module='.$mId.'&id_order='.$curOr.'&key='.$curSk);
    }
}
