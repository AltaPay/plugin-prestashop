<?php
/**
 * NOTICE OF LICENSE
 *
 * This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * @author Simion Zafiu <simion.zafiu@valitor.com>
 * @copyright Copyright (C) 2019 Valitor  (https://valitor.com)
 * @license GNU General Public License v3.0 <http://www.gnu.org/licenses/gpl-3.0.html>
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/classes/Terminal.php';
require_once dirname(__FILE__) . '/classes/MerchantAPI.php';
require_once dirname(__FILE__) . '/helpers.php';

class VALITOR extends PaymentModule
{
    private $Mhtml = '';
    private $postErrors = array();
    private $paymentMethodIconDir = 'views/img/payment_icons';
    
    public $url;
    public $terminal;
    public $username;
    public $password;
    public $payment_type;

    public function __construct()
    {
        $this->name = 'valitor';
        $this->tab = 'payments_gateways';
        $this->version = '2.4.0';
        $this->v16 = _PS_VERSION_ >= '1.6.0.5';
        $this->v17 = _PS_VERSION_ >= '1.7.6.1';
        $this->author = 'Valitor International A/S';
        $this->is_eu_compatible = 1;
        $this->ps_versions_compliancy = array('min' => '1.6.0.5' , 'max' => '1.7.6.1');

        $this->currencies = true;
        $this->currencies_mode = 'checkbox';

        $this->bootstrap = true;

        $config = Configuration::getMultiple(array(
            'VALITOR_USERNAME',
            'VALITOR_PASSWORD',
            'VALITOR_URL',
            'VALITOR_TERMINAL'
        ));
        if (isset($config['VALITOR_USERNAME'])) {
            $this->username = $config['VALITOR_USERNAME'];
        }
        if (isset($config['VALITOR_PASSWORD'])) {
            $this->password = $config['VALITOR_PASSWORD'];
        }
        if (isset($config['VALITOR_URL'])) {
            $this->url = $config['VALITOR_URL'];
        }
        

        parent::__construct();

        $this->displayName = $this->l('Valitor-Omni for Prestashop');
        $this->description = $this->l('Valitor-Omni for Prestashop - We make buying and selling easy');
        $this->confirmUninstall = $this->l('Are you sure about removing these details?');

        // Make sure currencies are configured for this payment module
        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->l('No currency has been set for this module.');
        }
    }

    /**
     * Called on install
     */
    public function install()
    {
        if (!parent::install()
            || !$this->registerHook('payment')
            || !$this->registerHook('paymentOptions')
            || !$this->registerHook('paymentReturn')
            || !$this->registerHook('adminOrder')
            || !$this->registerHook('actionOrderStatusUpdate')
            || !$this->registerHook('displayBackOfficeHeader')) {
            return false;
        }

        /* This table captures the payment information */
        if (!Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'valitor_order` (
			`id_order` int(10) unsigned NOT NULL,
			`unique_id` varchar(255) NOT NULL,
			`payment_id` varchar(255) NULL,
			`cardMask` varchar(20) NULL,
			`cardToken` varchar(255) NULL,
			`cardBrand` varchar(255) NULL,
			`cardCountry` varchar(255) NULL,
			`paymentType` varchar(255) NULL,
			`paymentStatus` varchar(255) NULL,
			`paymentNature` varchar(255) NULL,
			`requireCapture` tinyint(1) NOT NULL DEFAULT \'0\',
			`errorCode` varchar(255) NULL,
			`errorText` varchar(255) NULL,
            `latestError` varchar(255) NULL,
			`date_add` varchar(50) NOT NULL,
			PRIMARY KEY (`id_order`),
			UNIQUE KEY `unique_id` (`unique_id`),
			KEY `cardToken` (`cardToken`)
		) ENGINE='._MYSQL_ENGINE_.'  DEFAULT CHARSET=utf8')) {
            $this->context->controller->errors[] = Db::getInstance()->getMsgError();
            return false;
        }

        /* Will add a new column if it doesn't exist.
        That way we keep the backwards compatibility while adding a new column.*/
        if (!Db::getInstance()->getRow('SELECT * FROM INFORMATION_SCHEMA.COLUMNS 
             WHERE TABLE_NAME = \'' . _DB_PREFIX_ . 'valitor_order\' AND COLUMN_NAME = \'latestError\'')) {
            if (!Db::getInstance()->Execute('ALTER TABLE ' . _DB_PREFIX_ .
            'valitor_order ADD COLUMN latestError varchar(256) NULL')) {
                $this->context->controller->errors[] = Db::getInstance()->getMsgError();
                return false;
            }
        }

        /* This table captures each of the transaction details.  An order may or may not exist, and a transaction
        can exist multiple times for each cart */
        if (!Db::getInstance()->Execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'valitor_transaction` (
			`id` int(255) NOT NULL AUTO_INCREMENT,
			`id_cart` int(255) unsigned NOT NULL,
			`unique_id` varchar(255) NOT NULL,
			`amount` varchar(255) NOT NULL,
			`token` varchar(255) NOT NULL,
			`payment_form_url` TEXT NOT NULL,
			`is_cancelled` tinyint(1) NULL DEFAULT \'0\',
			`date_add` varchar(50) NOT NULL,
			PRIMARY KEY (`id`),
			UNIQUE KEY `unique_id` (`unique_id`),
			KEY `id_cart` (`id_cart`),
			KEY `token` (`token`)
		) ENGINE='._MYSQL_ENGINE_.'  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1')) {
            $this->context->controller->errors[] = Db::getInstance()->getMsgError();
            return false;
        }

        /* This table contains the payment methods / terminals */
        if (!Db::getInstance()->Execute("CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."valitor_terminals` (
			`id_terminal` int(11) NOT NULL AUTO_INCREMENT,
			`display_name` varchar(255) DEFAULT NULL,
            `icon_filename` varchar(100) DEFAULT NULL,
			`remote_name` varchar(255) DEFAULT NULL,
			`payment_type` varchar(32) DEFAULT NULL,
			`currency` varchar(100) DEFAULT NULL,
			`position` int(11) NOT NULL DEFAULT '0',
			`active` int(11) NOT NULL DEFAULT '0',
			PRIMARY KEY (`id_terminal`)
		) ENGINE="._MYSQL_ENGINE_."  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1")) {
            $this->context->controller->errors[] = Db::getInstance()->getMsgError();
            return false;
        }

        /* This table contains count of captured/refunded order lines */
        if (!Db::getInstance()->Execute("CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."valitor_orderlines` (
		`valitor_payment_id` varchar(36) NOT NULL,
		`product_id` int(10) NOT NULL,
		`captured` int(10) NOT NULL DEFAULT 0,
		`refunded` int(10) NOT NULL DEFAULT 0,
		PRIMARY KEY (`valitor_payment_id`,`product_id`)
		) ENGINE="._MYSQL_ENGINE_." DEFAULT CHARSET=utf8")) {
            $this->context->controller->errors[] = Db::getInstance()->getMsgError();
            return false;
        }
        $this->createOrderState();

        return true;
    }

    /**
     * Called on uninstall
     * Leaves tables in place in order to not loose history.
     */
    public function uninstall()
    {
        if (!Configuration::deleteByName('VALITOR_USERNAME')
            || !Configuration::deleteByName('VALITOR_PASSWORD')
            || !Configuration::deleteByName('VALITOR_URL')
            || !parent::uninstall()) {
            return false;
        }
        return true;
    }

    /**
     * Merchant details form
     *
     * @return String HTML for display
     */
    public function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Merchant details'),
                    'icon' => 'icon-cog'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('API username'),
                        'name' => 'VALITOR_USERNAME',
                        'required' => true
                    ),
                    array(
                        'type' => 'password',
                        'label' => $this->l('API password'),
                        'desc' => 'Fill this to change the password',
                        'name' => 'VALITOR_PASSWORD'
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('API URL'),
                        'desc' => 'Typically your installation for testing will be 
                        "https://testgateway.altapaysecure.com/" and for production it will be 
                        "https://yourdomain.altapaysecure.com/". 
                        Your Username and Password may be different for testing and live.',
                        'name' => 'VALITOR_URL',
                        'required' => true
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                )
            ),
        );
        if(isset($_GET['errorMessage'])) {
            $this->Mhtml .= '<div class="alert alert-danger">Incorrect payment gateway account details</div>';
        }
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ?
        Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.
        '&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    /**
     * List of terminals
     *
     * @return String HTML for display
     */
    public function renderTerminalList()
    {
        $fields_list = array(
            'id_terminal' => array(
                'title' => $this->l('ID'),
                'width' => 100,
                'type' => 'text',
            ),
            'display_name' => array(
                'title' => $this->l('Name'),
                'width' => 140,
                'type' => 'text',
            ),
            'currency' => array(
                'title' => $this->l('Currency'),
                'width' => 50,
                'type' => 'text',
            ),
            'remote_name' => array(
                'title' => $this->l('Terminal'),
                'width' => 140,
                'type' => 'text',
            ),
            'payment_type' => array(
                'title' => $this->l('Payment type'),
                'width' => 140,
                'type' => 'text',
            ),
            'active' => array(
                'title' => $this->l('Status'),
                'active' => 'active',
                'type' => 'bool',
                'width' => 'auto',
                'orderby' => false,
                'search' => false,
            ),
        );

        $helper = new HelperList();
        $helper->shopLinkType = '';
        $helper->simple_header = false;
        $helper->actions = array('edit');
        $helper->identifier = 'id_terminal';
        $helper->position_identifier = 'position';
        $helper->show_toolbar = true;
        $helper->toolbar_btn = array(
            'new' => array(
                'href' => AdminController::$currentIndex.'&configure='.$this->name.'&add'.$this->name.'&token='
                .Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Add new')
            )
        );
        $helper->title = 'Terminals';
        $helper->table = 'valitor_terminals';
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        $helper->orderBy = 'id_terminal';
        $helper->orderWay = 'ASC';
        $content = Terminal::getTerminals();

        return $helper->generateList($content, $fields_list);
    }
    /* ******************************** */

    /**
     * Form for adding and editing terminals
     *
     * @return String HTML for display
     */
    public function renderAddForm()
    {
        $currency_options = array();
        foreach (Currency::getCurrencies((int)Context::getContext()->language->id) as $currency) {
            $currency_options[] = array(
                "id" => $currency->iso_code,
                "name" => $currency->name . " (" . $currency->iso_code . ")"
            );
        }

        $icon_options = array();
        $fields_form = array();
        $directory = _PS_MODULE_DIR_ . "/" . $this->name . "/" . $this->paymentMethodIconDir;
        $scanned_directory = array_diff(scandir($directory), array('..', '.', '.DS_Store'));
        foreach ($scanned_directory as $filename) {
            $icon_options[] = array(
                "id" => $filename,
                "name" => $filename
            );
        }
        $fields_form[0]['form'] = array(
                'legend' => array(
                    'title' => $this->l('Terminal details'),
                    'icon' => 'icon-cog'
                ),
                'input' => array(
                    array(
                        'type' => 'hidden',
                        'name' => 'id_terminal'
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Display name'),
                        'desc' => $this->l('What the customer sees'),
                        'name' => 'display_name',
                        'required' => true
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Icon'),
                        'desc' => $this->l('Upload icons in size 20x20 pixels to ')
                        . $this->_path . $this->paymentMethodIconDir,
                        'name' => 'icon_filename',
                        'required' => true,
                        'options' => array(
                            'query' => $icon_options,
                            'id' => 'id',
                            'name' => 'name'
                        )
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('VALITOR terminal'),
                        'desc' => $this->l('Name of the terminal in the VALITOR merchant information interface'),
                        'name' => 'remote_name',
                        'required' => true,
                        'options' => array(
                            'query' => $this->getVALITORTerminals(),
                            'id' => 'id',
                            'name' => 'name'
                        )
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Currency'),
                        'name' => 'currency',
                        'required' => true,
                        'options' => array(
                            'query' => $currency_options,
                            'id' => 'id',
                            'name' => 'name'
                        )
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Payment type'),
                        'desc' => $this->l('How the payment is handled'),
                        'name' => 'payment_type',
                        'required' => true,
                        'options' => array(
                            'query' => array(
                                array(
                                    'id_option' => 'payment',
                                    'name' => 'Authorize only'
                                ),
                                array(
                                    'id_option' => 'paymentAndCapture',
                                    'name' => 'Authorize and capture'
                                ),
                            ),
                            'id' => 'id_option',
                            'name' => 'name'
                        )
                    ),
                    array(
                        'type' => 'radio',
                        'label' => $this->l('Status'),
                        'name' => 'active',
                        'required' => true,
                        'is_bool' => true,
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Disabled')
                            ),
                        ),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
                'buttons' => array(
                    array(
                        'href' => AdminController::$currentIndex.
                        '&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'),
                        'title' => $this->l('Back to list'),
                        'icon' => 'process-icon-back'
                    )
                ),
            );
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = 'valitor';
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        $helper->show_toolbar = false;
        $helper->table = 'valitor_terminals';

        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;

        $helper->id = (int)Tools::getValue('id_terminal');
        $helper->submit_action = 'savevalitor_terminals';
        
        $helper->tpl_vars = array(
            'fields_value' => $this->getFormValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        return $helper->generateForm($fields_form);
    }

    /**
     * Info displayed at the top on the module config page
     */
    protected function displayVALITOR()
    {
        $html = $this->display(__FILE__, 'config.tpl');
        $html .= $this->renderForm();
        $html .= $this->renderTerminalList();

        return $html;
    }


    /* ******************************** */

    /**
     * Field values for the merchant details form
     *
     * @return Array Array of curent configuration values
     */
    public function getConfigFieldsValues()
    {
        return array(
            'VALITOR_USERNAME' => Tools::getValue('VALITOR_USERNAME', Configuration::get('VALITOR_USERNAME')),
            'VALITOR_PASSWORD' => Tools::getValue('VALITOR_PASSWORD', Configuration::get('VALITOR_PASSWORD')),
            'VALITOR_URL' => Tools::getValue('VALITOR_URL', Configuration::get('VALITOR_URL')),
        );
    }
    /* ******************************** */

    /**
     * Get field values for add/edit terminal form
     *
     * @return Array Associative array of object values
     */
    public function getFormValues()
    {
        $id_terminal  = (int)Tools::getValue('id_terminal');
        
    
        if ($id_terminal > 0) {
            $data = new Terminal($id_terminal);
        } else {
            $def = Terminal::$definition;
            foreach ($def['fields'] as $field_name => $stuff) {
                $data[$field_name] = Tools::getValue($field_name);
            }
        }
        return (array)$data;
    }
    /* ******************************** */

    /**
     * Return content for the configuration in back office
     *
     * @return String HTML for display
     */
    public function getContent($params)
    {
        //$id_terminal = (int)Tools::getValue('id_terminal');

        /* Display: add/edit terminal form */
        if (Tools::isSubmit('updatevalitor_terminals') || Tools::isSubmit('addvalitor')) {
            $this->Mhtml .= $this->renderAddForm();
            return $this->Mhtml;
        } /* Process: capture, refund, release */
        elseif (Tools::isSubmit('payment_actions')) {
            $this->processPaymentActions($params);
        } /* Process: save terminal */
        elseif (Tools::isSubmit('savevalitor_terminals')) {
            if (!$this->postProcessTerminal()) {
                return $this->Mhtml . $this->renderAddForm();
            } else {
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminModules', false) . '&configure='
                . $this->name .'&token=' . Tools::getAdminTokenLite('AdminModules'));
            }
        } /* Process: enable/disable */
        elseif (Tools::isSubmit('activevalitor_terminals')) {
            $this->postProcessActive();
            return $this->displayVALITOR();
        } /* Process: save merchant details */
        elseif (Tools::isSubmit('btnSubmit')) {
            $this->postValidation();
            if (!count($this->postErrors)) {
                $this->postProcess();
                return $this->displayVALITOR();
            } else {
                foreach ($this->postErrors as $err) {
                    $this->Mhtml .= '<div class="alert alert-danger">'.$err.'</div>';
                    $this->Mhtml .= $this->displayVALITOR();
                    return $this->Mhtml;
                }
            }
        } /* Default display */
        else {
            $this->Mhtml .= $this->displayVALITOR();
            return $this->Mhtml;
        }
    } /* ******************************** */

    /**
     * Handle payment processing
     * capture, refund, release
     */
    private function processPaymentActions($params)
    {
        if (!(Tools::getValue('action') && Tools::getValue('payment_id'))) {
            return;
        }

        $payment_id = (int)Tools::getValue('payment_id');

        header('Content-Type: application/json');

        // Merchant API
        $api = new MerchantAPI();
        try {
            $api->init($this->getVALITORUrl(), $this->getAPIUsername(), $this->getAPIPassword());
        } catch (Exception $e) {
            saveLastErrorMessage($payment_id, $e->getMessage());

            echo json_encode(
                array(
                    'status'  => "error",
                    'message' => "Connection error: " . $e->getMessage()
                )
            );
            die();
        }

        // CAPTURE
        if (Tools::getValue('action')=='capture') {
            try {
                $orderID= Tools::getValue('ap_order_id');
                $orderLines = Tools::getValue('ap_order_qty');
                $productID = Tools::getValue('ap_product_id');
                $prodcutAttributeID = Tools::getValue('ap_attribute_id');
                $discountPercentage = Tools::getValue('ap_coupon_discount');
                $ap_orderLines = $this->populateOrderLinesFromPost($orderLines,$discountPercentage,$orderID,$productID,$prodcutAttributeID);
                $api->captureAmount($payment_id, Tools::getValue('amount'), $ap_orderLines);
                mark_as_captured($payment_id, $orderLines);
            } catch (Exception $e) {
                saveLastErrorMessage($payment_id, $e->getMessage());

                echo json_encode(
                    array(
                        'status'  => "error",
                        'message' => "Could not capture reservation. Error: " . $e->getMessage()
                    )
                );
                die();
            }

            echo json_encode(
                array(
                    'status'  => "success",
                    'message' => "Reservation captured successfully"
                )
            );
            die();
        } // REFUND
        elseif (Tools::getValue('action')=='refund') {
            try {
                $goodWillRefund = false;
                $refundAmount = Tools::getValue('amount');
                $orderID= Tools::getValue('ap_order_id');
                $orderLines = Tools::getValue('ap_order_qty');
                $productID = Tools::getValue('ap_product_id');
                $prodcutAttributeID = Tools::getValue('ap_attribute_id');
                $discountPercentage = Tools::getValue('ap_coupon_discount');
                if (!is_array($orderLines)) {
                    $orderLines = array();
                }
                if (Tools::getValue('goodwillrefund') == 'yes') {
                    $goodWillRefund = true;
                }
                $ap_orderLines = $this->populateOrderLinesFromPost($orderLines,$discountPercentage,$orderID,$productID,$prodcutAttributeID, $goodWillRefund);

                // Add a dummy orderLine array in case no orderLines are parsed in the refund
                if ($ap_orderLines === array() && $goodWillRefund) {
                    $ap_orderLines = $this->createDummyOrderLinesArr($refundAmount);
                }
                $api->refundAmount($payment_id, $refundAmount, $ap_orderLines);
                $refundUpdate = mark_as_refunded($payment_id, $orderLines);
                if (!$refundUpdate) {
                    throw new Exception("The refund could not be updated in database");
                }
            } catch (Exception $e) {
                saveLastErrorMessage($payment_id, $e->getMessage());

                echo json_encode(
                    array(
                        'status'  => "error",
                        'message' => "Could not refund payment. Error: " . $e->getMessage()
                    )
                );
                die();
            }

            echo json_encode(
                array(
                    'status'  => "success",
                    'message' => "Payment refunded successfully"
                )
            );
            die();
        } // RELEASE
        elseif (Tools::getValue('action')=='release') {
            try {
                $api->release($payment_id);
            } catch (Exception $e) {
                saveLastErrorMessage($payment_id, $e->getMessage());

                echo json_encode(
                    array(
                        'status'  => "error",
                        'message' => "Could not release reservation. Error: " . $e->getMessage()
                    )
                );
                die();
            }

            echo json_encode(
                array(
                    'status'  => "success",
                    'message' => "Reservation released successfully"
                )
            );
            die();
        }
    }

    /**
     * Handle submission of terminal form
     */
    private function postProcessTerminal()
    {
        // Update existing
        if ($id_terminal = Tools::getValue('id_terminal')) {
            $terminal = new Terminal((int)$id_terminal);
        } // New
        else {
            $terminal = new Terminal;
        }

        // VALITOR terminal
        $ap_terminal = $this->getVALITORTerminal(Tools::getValue('remote_name'));

        // Currency supported?
        if (!$ap_terminal->hasCurrency(Tools::getValue('currency'))) {
            $getVal = Tools::getValue('currency');
            $this->Mhtml .=
            sprintf('<div class="alert alert-danger">Selected terminal does not support currency %s</div>', $getVal);
            return false;
        }

        // Fields
        $fields = array('display_name', 'remote_name', 'icon_filename', 'currency', 'payment_type', 'active');
        foreach ($fields as $field_name) {
            $terminal->{$field_name} = Tools::getValue($field_name);
        }

        // Validate
        $result = $terminal->validateFields(false, true);
        if ($result == 1) {
            $terminal->save();
            return true;
        } else {
            $this->Mhtml .= '<div class="alert alert-danger">'.$result.'</div>';
        }

        return false;
    }
    /* ******************************** */

    private function postProcessActive()
    {
        $id_terminal = Tools::getValue('id_terminal');
        if (!$id_terminal) {
            return;
        }

        $terminal = new Terminal((int)$id_terminal);
        $terminal->active = !(bool)$terminal->active;
        $terminal->save();
    }

    /**
     * Validate merchant details form
     */
    private function postValidation()
    {
        if (Tools::isSubmit('btnSubmit')) {
            if (!Tools::getValue('VALITOR_USERNAME')) {
                $this->postErrors[] = $this->l('API username is required');
            } elseif (!Tools::getValue('VALITOR_URL')) {
                $this->postErrors[] = $this->l('API URL is required');
            }
            if (!filter_var(Tools::getValue('VALITOR_URL'), FILTER_VALIDATE_URL)) {
                $this->postErrors[] = $this->l('Incorrect format for the API URL - Use "https://paymentURL"');
            }
        }
    }
    /* ******************************** */

    /* Handle merchant details form */
    private function postProcess()
    {
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('VALITOR_USERNAME', Tools::getValue('VALITOR_USERNAME'));
            $urlPath = preg_replace('/\s+/', '', Tools::getValue('VALITOR_URL'));
            if (Tools::substr($urlPath, -1) != '/') {
                Configuration::updateValue('VALITOR_URL', $urlPath .= '/');
            } elseif (Tools::substr($urlPath, -1) == '/') {
                Configuration::updateValue('VALITOR_URL', $urlPath);
            }
            if (Tools::getValue('VALITOR_PASSWORD') !== "") {
                Configuration::updateValue('VALITOR_PASSWORD', Tools::getValue('VALITOR_PASSWORD'));
            }
        }
        $this->Mhtml .= '<div class="alert alert-success"> '.$this->l('Settings updated').'</div>';
    }
    /* ******************************** */

    /**
     * Displays the error that occurred in the hookActionOrderStatusUpdate method, if any.
     *
     * @param $params
     * @return mixed
     */
    public function hookBackOfficeHeader($params)
    {
        $cookie = $this->context->cookie;
        
        if ($cookie->valitorError) {
            $this->context->controller->errors[] = $cookie->valitorError;

            // unset the variable:
            $cookie->valitorError = null;
        }

        // always returns false because there is no template to display
        return false;
    }

    /**
     * Captures a payment when the status is changed to Shipped.
     *
     * @param $params
     */
    public function hookActionOrderStatusUpdate($params)
    {
        $results = $this->selectOrder($params);

        if (!$results) {
            return;
        }

        $payment_id = $results['payment_id'];

        /** @var OrderStateCore */
        $newStatus = $params['newOrderStatus'];

        $shipped_status = Configuration::get('PS_OS_SHIPPING');

        if ($newStatus->id == $shipped_status) { // a capture will be made if necessary
            try {
                $api = new MerchantAPI();

                $api->init($this->getVALITORUrl(), $this->getAPIUsername(), $this->getAPIPassword());

                $ap_payment = $api->getPaymentDetails($payment_id);

                // Maybe there was a full or a partial capture before, so we need to calculate what wasn't captured yet:
                $amountToCapture = round($ap_payment->CapturedAmount - $ap_payment->ReservedAmount);

                if ($amountToCapture > 0) {
                    $api->captureAmount($payment_id, $amountToCapture);
                    mark_as_captured($payment_id);
                }
            } catch (Exception $e) {
                $cookie=$this->context->cookie;

                // Saves the error in a cookie, to display it if a HTTP redirect occurs:
                $msg = $e->getMessage();
                $cookie->valitorError = Tools::displayError('Error trying to change the order status to Shipped:'.$msg);

                // Saves the error in errors[], to display it if there is no HTTP redirect:
                $this->context->controller->errors[] = $cookie->valitorError;

                // Saves the error in the database:
                saveLastErrorMessage($payment_id, $cookie->valitorError);
            }
        }
    }


    /**
     * Displays payment info on order detail pages in back office
     */
    public function hookAdminOrder($params)
    {
        $results = $this->selectOrder($params);
        
        if (!$results) {
            return false;
        }

        # collect order info
        
        $order_detail = new Order((int)$params['id_order']);
        $product_detail = $order_detail->getProducts();
        $orderId = $params['id_order'];
        $this->smarty->assign('ap_order_id', $orderId);
        $this->smarty->assign('ap_product_details', $product_detail);
        $discountPercent = $this->getCartDiscount();
        $this->smarty->assign('ap_coupon_discount', $discountPercent);
        $ap_orders = array();
        $ap_orderlines = $this->getOrderActions($results['payment_id']);
        foreach ($product_detail as $product) {
            $ap_orders[$product['product_id']] = array(
                'captured' => "0",
                'refunded' => "0",
            );

            foreach ($ap_orderlines as $orderline) {
                if ($orderline['product_id'] == $product['product_id']) {
                    $ap_orders[$product['product_id']]['captured'] = $orderline['captured'];
                    $ap_orders[$product['product_id']]['refunded'] = $orderline['refunded'];
                }
            }
        }
        $this->smarty->assign('ap_orders', $ap_orders);

        # collect info from VALITOR - fail gracefully
        $api = new MerchantAPI();
        try {
            $api->init($this->getVALITORUrl(), $this->getAPIUsername(), $this->getAPIPassword());
            $ap_payment = $api->getPaymentDetails($results['payment_id']);
            $this->smarty->assign('ap_paymentinfo', $ap_payment);
        } catch (Exception $e) {
            $this->smarty->assign('ap_error', "Error: " . $e->getMessage());
        }

        # prepare for view
        $paymentinfo = array(
            'Transaction Date' => Tools::htmlentitiesUTF8(date("F j, Y, g:i a", $results['date_add'])),
            'Transaction ID' => Tools::htmlentitiesUTF8($results['unique_id']),
            'Payment ID' => Tools::htmlentitiesUTF8($results['payment_id']),
            'Card Brand'=> Tools::htmlentitiesUTF8($results['cardBrand']),
            'Card Number'=> Tools::htmlentitiesUTF8($results['cardMask']),
            'Card Country'=> Tools::htmlentitiesUTF8($results['cardCountry']),
            'Payment Type'=> Tools::htmlentitiesUTF8($results['paymentType']),
            'Payment Status'=> Tools::htmlentitiesUTF8($results['paymentStatus']),
            'Payment Nature'=> Tools::htmlentitiesUTF8($results['paymentNature']),
            'Latest Error'=> Tools::htmlentitiesUTF8($results['latestError']),
        );
        $fet = $this->context->link;
        $tname = $this->name;
        $this->smarty->assign('paymentinfo', $paymentinfo);
        $this->smarty->assign('payment_id', $results['payment_id']);
        $this->smarty->assign('payment_amount', $results['amount']);
        $this->smarty->assign('payment_captured', !$results['requireCapture']);
        $this->smarty->assign('this_path', $this->_path);
        $this->smarty->assign('ajax_url', $fet->getAdminLink('AdminModules').'&configure='.$tname."&payment_actions");
        $this->smarty->assign('token', Tools::getAdminTokenLite('AdminModules'));

        $this->context->controller->addCSS($this->_path.'views/css/admin_order.css', 'all');
        $this->context->controller->addJS($this->_path.'views/js/admin_order.js');

        return $this->display(__FILE__, '/views/templates/hook/admin_order.tpl');
    }

    //hookPayment is utilized in prestashop 1.6
    public function hookPayment($params)
    {
        if (!$this->active) {
            return;
        }
        // Check that we can accept this currency (currency restrictions)
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $this->context->controller->addCSS($this->_path.'css/payment.css', 'all');

        // Fetch payment methods
        $currency = $this->getCurrencyForCart($params['cart']);
        $paymentMethods = Terminal::getActiveTerminalsForCurrency($currency->iso_code);

        $this->smarty->assign(array(
            'this_path' => $this->_path,
            'this_path_valitor' => $this->_path,
            'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/',
            'methods' => $paymentMethods,
            'PS_STOCK_MANAGEMENT' => Configuration::get('PS_STOCK_MANAGEMENT'),
        ));
        return $this->display(__FILE__, 'payment.tpl');
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }
        // Check that we can accept this currency (currency restrictions)
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $this->context->controller->addCSS($this->_path.'css/payment.css', 'all');

        // Fetch payment methods
        $currency = $this->getCurrencyForCart($params['cart']);
        $paymentMethods = Terminal::getActiveTerminalsForCurrency($currency->iso_code);

        $this->smarty->assign(
            $this->getTemplateVarInfos()
        );
        $paymentsOptions = array();
        foreach ($paymentMethods as $paymentMethod) {
            $actionText=$this->l('Pay with').' '.$paymentMethod['display_name'];
            $paymentOptions = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
            $terminal_id=$paymentMethod['id_terminal'];
            $terminal=array('method'=> $terminal_id);
            $template = 'module:valitor/views/templates/hook/payment17.tpl';
            $paymentOptions->setCallToActionText($actionText)
                        ->setAction($this->context->link->getModuleLink('valitor', 'payment', $terminal))
                        ->setModuleName($this->name)
                        ->setAdditionalInformation($this->fetch($template))
                        ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/views/img/payment_icons/'
                        .$paymentMethod['icon_filename']));
            $paymentsOptions[] = $paymentOptions;
        }
        return $paymentsOptions;
    }

    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return;
        }
        //Prestashop 1.7 doesn't have the $params['objOrder']
        if (!isset($params['objOrder']) || !is_object($params['objOrder'])) {
            $params['objOrder'] = $params['order'];
        }
        
        $state = $params['objOrder']->getCurrentState();
        $results=Db::getInstance()->getRow('SELECT * 
        FROM `'._DB_PREFIX_.'valitor_order` WHERE id_order='.$params['objOrder']->id);
        if ($state == Configuration::get('PS_OS_PAYMENT') || $state == Configuration::get('PS_OS_OUTOFSTOCK')) {
            $this->smarty->assign(array(
                'total_to_pay' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false),
                'status' => 'ok',
                'unique_id' => $results['unique_id'],
                'payment_id' => $results['payment_id'],
                'id_order' => $params['objOrder']->id
            ));
            if (isset($params['objOrder']->reference) && !empty($params['objOrder']->reference)) {
                $this->smarty->assign('reference', $params['objOrder']->reference);
            }
        } else {
            //if 'open' = Configuration::get('VALITOR_OS_PENDING')
            $this->smarty->assign(array(
                'total_to_pay' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false),
                'status' => 'open',
                'unique_id' => $results['unique_id'],
                'payment_id' => $results['payment_id'],
                'id_order' => $params['objOrder']->id
            ));
            if (isset($params['objOrder']->reference) && !empty($params['objOrder']->reference)) {
                $this->smarty->assign('reference', $params['objOrder']->reference);
            }
        }
        return $this->display(__FILE__, 'payment_return.tpl');
    }

    public function getVALITORUrl()
    {
        return $this->url;
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    private function getCurrencyForCart($cart)
    {
        return new Currency($cart->id_currency);
    }

    /**
     * Get the remote name of the terminal associated with
     * this payment method. Will check if currency matches the remote terminal.
     */
    private function getTerminal($terminal_id = false, $currency = false)
    {
        if ($terminal_id === false || $currency === false) {
            return false;
        }

        $terminal = new Terminal($terminal_id);
        $terminalId = $terminal->id_terminal;
        $terminalCurr = $terminal->currency;
        if ($terminalId === null || Tools::strtolower($terminalCurr) !== Tools::strtolower($currency)) {
            return false;
        }

        return $terminal;
    }

    private function getAPIUsername()
    {
        return $this->username;
    }

    private function getAPIPassword()
    {
        return $this->password;
    }

    /**
     * Create a new order state
     */
    public function createOrderState()
    {
        if (!Configuration::get('VALITOR_OS_PENDING')) {
            $orderState = new OrderState();
            $orderState->name = array();

            foreach (Language::getLanguages() as $language) {
                $orderState->name[$language['id_lang']] = 'Awaiting payment processing';
            }

            $orderState->color = '#ffff5a';

            $orderState->logable = false;
            $orderState->invoice = false;
            $orderState->hidden = false;
            $orderState->send_email = false;
            $orderState->shipped = false;
            $orderState->paid = false;
            $orderState->delivery = false;

            if ($orderState->add()) {
                $source = dirname(__FILE__).'/views/img/os_pending.gif';
                $destination = dirname(__FILE__).'/../../img/os/'.(int)$orderState->id.'.gif';
                copy($source, $destination);
            }
            Configuration::updateValue('VALITOR_OS_PENDING', (int)$orderState->id);
        }
    }

    /** Creates the transaction to VALITOR which should result in the payment form page URL.
     *  @return An array containing the URL.
     *  If the transaction failed, the array contains information about the failure
     */
    public function createTransaction($payment_method = false)
    {
        $cart = $this->context->cart;

        // terminal
        $terminal = $this->getTerminal($payment_method, $this->context->currency->iso_code);
        if (!is_object($terminal)) {
            $message = "Could not determine remote terminal - possibly currency mismatch";
            Logger::addLog($message, 3, 0, $this->name, $this->id, true);
            return array(
                'success' => false,
                'result' => 'failure',
                'message' => $message,
                'additionalInfo' => $message,
                'payment_form_url' => false,
            );
        }
        $cgConf=array();
        // config
        $cgConf['user']=$this->getAPIUsername();
        $cgConf['password']=$this->getAPIPassword();
        $cgConf['payment_type']=$terminal->payment_type;
        $cgConf['valitor_url']=$this->getVALITORUrl();
        $cgConf['currency']=$this->context->currency->iso_code;
        $cgConf['language']=$this->context->language->iso_code;
        $cgConf['uniqueid']=$cart->id.'_'.time().rand(100, 999);
        $cgConf['terminal']=$terminal->remote_name;
        $cgConf['cookie'] = isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : null;
                
        $callback=array();
        // callbacks
        $callback['callback_form']=$this->context->link->getModuleLink(
            $this->name,
            'callbackform',
            array(),
            true,
            $this->context->language->id,
            $this->context->shop->id
        );
        $callback['callback_ok']=$this->context->link->getModuleLink(
            $this->name,
            'callbackok',
            array(),
            true,
            $this->context->language->id,
            $this->context->shop->id
        );
        $callback['callback_fail']=$this->context->link->getModuleLink(
            $this->name,
            'callbackfail',
            array(),
            true,
            $this->context->language->id,
            $this->context->shop->id
        );
        $callback['callback_open']=$this->context->link->getModuleLink(
            $this->name,
            'callbackopen',
            array(),
            true,
            $this->context->language->id,
            $this->context->shop->id
        );
        $callback['callback_notification']=$this->context->link->getModuleLink(
            $this->name,
            'callbacknotification',
            array(),
            true,
            $this->context->language->id,
            $this->context->shop->id
        );
        $callback['callback_redirect']=$this->context->link->getModuleLink(
            $this->name,
            'callbackredirect',
            array(),
            true,
            $this->context->language->id,
            $this->context->shop->id
        );
        $customer=array();
        // customer info
        $customer['billing_firstname']=$this->context->customer->firstname;
        $customer['billing_lastname']=$this->context->customer->lastname;
        $customer['email']=$this->context->customer->email;

        // billing address
        $invoice_address = new Address($this->context->cart->id_address_invoice);
        $country = new Country($invoice_address->id_country);
        $state = new State($invoice_address->id_state);
        $customer['billing_address']=$invoice_address->address1;
        $customer['billing_city']=$invoice_address->city;
        $customer['billing_postal']=$invoice_address->postcode;
        $customer['billing_region']=$state->iso_code;
        $customer['billing_country']=$country->iso_code;

        // phone
        $invoiceAph = $invoice_address->phone;
        $customer['customer_phone']= $invoice_address->phone != '' ? $invoiceAph : $invoice_address->phone_mobile;

        // shipping address
        $sp_address = new Address($this->context->cart->id_address_delivery);
        $sp_country = new Country($sp_address->id_country);
        $sp_state = new State($sp_address->id_state);
        $customer['shipping_address']=$sp_address->address1;
        $customer['shipping_city']=$sp_address->city;
        $customer['shipping_postal']=$sp_address->postcode;
        $customer['shipping_region']=$sp_state->iso_code;
        $customer['shipping_country']=$sp_country->iso_code;
        $customer['shipping_firstname']=$sp_address->firstname;
        $customer['shipping_lastname']=$sp_address->lastname;

        //Calling transactionInfo method from helpers file
        $transactionInfo = transactionInfo();

        // Decode the HTML entities from the address data
        $customer = $this->decodeHtmlEntitiesArrayValues($customer);

        $amount = $cart->getOrderTotal(true, Cart::BOTH);

        $api=null;
        try {
            $api = new ValitorMerchantAPI($cgConf['valitor_url'], $cgConf['user'], $cgConf['password'], null);
            $response = $api->login();
            
            if (!$response->wasSuccessful()) {
                $resErrMsg = $response->getErrorMessage();
                $resErrCode = $response->getErrorCode();
                throw new Exception("Could not login to the Merchant API: ".$resErrMsg, $resErrCode);
            }
        } catch (Exception $e) {
            Logger::addLog($e->getMessage(), 3, $e->getCode(), $this->name, $this->id, true);
            return array(
                'success' => false,
                'result' => 'failure',
                'message' => 'unable to connect to gateway',
                'additionalInfo' => $e->getMessage(),
                'payment_form_url' => false,
            );
        }

        try {
            $response = $api->createPaymentRequest(
                $cgConf['terminal'],
                $cgConf['uniqueid'],
                $amount,
                $cgConf['currency'],
                $cgConf['payment_type'],
                $customer,
                $cgConf['cookie'],
                $cgConf['language'],
                $callback,
                $transactionInfo,
                $this->getOrderLines($cart)
            );
            if (!$response->wasSuccessful()) {
                $resErrMsg = $response->getErrorMessage();
                $resErrCode = $response->getErrorCode();
                throw new Exception("Could not create the payment request: ".$resErrMsg, $resErrCode);
            }
            
            return array(
                'success' => true,
                'uniqueid' => $cgConf['uniqueid'],
                'amount' => $amount,
                'result' => 'Success',
                'payment_form_url' => $response->getRedirectURL(),
            );
        } catch (Exception $e) {
            Logger::addLog($e->getMessage(), 3, $e->getCode(), $this->name, $this->id, true);
            return array(
                'success' => false,
                'result' => 'failure',
                'message' => 'unable to obtain payment form url',
                'additionalInfo' => $e->getMessage(),
                'payment_form_url' => false,
            );
        }
    }


    /** @var CartCore */
    private function getOrderLines($cart)
    {
        $i = 0;
        $orderLines = array();
        $products = $cart->getProducts();
        $coupon = $this->context->cart->getCartRules();
        if(!empty($coupon)) {
            foreach ($coupon as $code) {
                $discountPercent = $code['reduction_percent'];
                foreach ($products as $p) {

                    if($p['id_product_attribute']) {
                        $itemID = $p['reference'].'-'.$p['id_product_attribute'];
                    }
                    else {
                        $itemID = $p['reference'];
                    }
                    $rateBasePrice = 1 + $p['rate']/100;

                    //Calculation of base price
                    $basePrice = $p['price_without_reduction']/$rateBasePrice;
                    // Mandatory keys for orderLines:
                    $orderLines[$i]['description'] = $p['name']; // Description of item.
                    $orderLines[$i]['itemId'] = $itemID ; // Item number (SKU)
                    $orderLines[$i]['quantity'] =  $p['cart_quantity'];
                    
                    // Unit price excluding sales tax, only two digits.
                    $orderLines[$i]['unitPrice'] =  (float)number_format(floor(100 * $basePrice) / 100, 2, '.', '');
            
                    // Optional keys for orderLines:
                    $orderLines[$i]['taxAmount'] =  (float)number_format($p['cart_quantity'] *  ($p['price_without_reduction'] - $basePrice), 2, '.', ''); // Tax amount should be the total tax amount.
                    //$orderLines[$i]['taxPercent'] = $couponAmount; //Tax Rate specified
                    $orderLines[$i]['goodsType'] = 'item'; // Order line Type - one of the following shipment|handling|item
                    
                    $orderLines[$i]['discount'] =  $discountPercent;

                    $i++;
                }
            }
        } else {
            foreach ($products as $p) {
                if($p['id_product_attribute']) {
                    $itemID = $p['reference'].'-'.$p['id_product_attribute'];
                }
                else {
                    $itemID = $p['reference'];
                }
                $discountAmount = $p['price_without_reduction']-$p['price_with_reduction'];
                $amountBeforeTax = ($discountAmount / $p['price_without_reduction']) * 100;
                $rateBasePrice = 1 + $p['rate']/100;

                //Calculation of base price
                $basePrice = $p['price_without_reduction']/$rateBasePrice;

                // Mandatory keys for orderLines:
                $orderLines[$i]['description'] = $p['name']; // Description of item.
                $orderLines[$i]['itemId'] =  $itemID; // Item number (SKU)
                $orderLines[$i]['quantity'] =  $p['cart_quantity'];
                
                // Unit price excluding sales tax, only two digits.
                $orderLines[$i]['unitPrice'] =   (float)number_format(floor(100 * $basePrice) / 100, 2, '.', '');
        
                // Optional keys for orderLines:
                $orderLines[$i]['taxAmount'] =  (float)number_format($p['cart_quantity'] *  ($p['price_without_reduction'] - $basePrice), 2, '.', ''); // Tax amount should be the total tax amount.
                //$orderLines[$i]['taxPercent'] = $couponAmount; //Tax Rate specified
                $orderLines[$i]['goodsType'] = 'item'; // Order line Type - one of the following shipment|handling|item
                
                $orderLines[$i]['discount'] = $amountBeforeTax;

                $i++;
            }
        }
        //Check if Cart Rule is being applied. If yes, then send the entry as a separate orderline
        // $coupon = $this->context->cart->getCartRules();
        // if(!empty($coupon)) {
        //     foreach ($coupon as $code) {
        //         $orderLines[$i]['description'] = $code['code']; // Description of item.
        //         $orderLines[$i]['itemId'] =  $code['name']; // Item number (SKU)
        //         $orderLines[$i]['quantity'] =  '1';
                
        //         // Unit price excluding sales tax, only two digits.
        //         $orderLines[$i]['unitPrice'] =  '-'.floor(100 * $code['value_real']) / 100;
        //         $orderLines[$i]['goodsType'] = 'handling';   
        //         $i++;
        //     }
        // }
        // Shipping keys.
        // Mandatory keys for orderLines:

        $carrier = $cart->getSummaryDetails()['carrier'];
        $orderLines[$i]['description'] = $carrier->delay;
        $orderLines[$i]['itemId'] = $carrier->name;
        $orderLines[$i]['quantity'] =  1;
        $orderLines[$i]['unitPrice'] =  $cart->getTotalShippingCost(null, false); // Shipping cost without tax
        // Optional keys for orderLines:
        $orderLines[$i]['taxAmount'] = $cart->getTotalShippingCost(null, true) - $orderLines[$i]['unitPrice'];
        $orderLines[$i]['goodsType'] = 'shipment';

        return $orderLines;
    }

    /**
     * Return a single terminal from VALITOR API
     */
    private function getVALITORTerminal($name)
    {
        $terminals = $this->getVALITORTerminals(true); // Objects please

        return $terminals[$name];
    }

    /**
     * Query the VALITOR API for available terminals
     *
     * @return array Array of terminals
     */
    private function getVALITORTerminals($objects = false)
    {
        require_once(_PS_MODULE_DIR_.'/valitor/lib/valitor/valitor-php-sdk/lib/ValitorMerchantAPI.class.php');
        $cgConf=array();
        $cgConf['user'] = $this->getAPIUsername();
        $cgConf['password'] = $this->getAPIPassword();
        $cgConf['valitor_url'] = $this->getVALITORUrl();

        $terminals = array();

        $api=null;
        try {
            $api = new ValitorMerchantAPI($cgConf['valitor_url'], $cgConf['user'], $cgConf['password'], null);
            $response = $api->login();
            if (!$response->wasSuccessful()) {
                $resErrMsg = $response->getErrorMessage();
                $resErrCode = $response->getErrorCode();
                throw new Exception("Could not login to the Merchant API: ".$resErrMsg, $resErrCode);
            }

            $responseTerminals = $api->getTerminals();
            $terminals = $responseTerminals->getTerminals();
        } catch (Exception $e) {
            Logger::addLog($e->getMessage(), 3, $e->getCode(), $this->name, $this->id, true);
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminModules', false) . '&configure='
            . $this->name .'&errorMessage&token=' . Tools::getAdminTokenLite('AdminModules'));
            die;
        }

        $terminal_array = array();

        foreach ($terminals as $terminal) {
            if (!$objects) {
                $terminal_array[$terminal->getTitle()] = array(
                    'id' => $terminal->getTitle(),
                    'name' => $terminal->getTitle()
                );
            } else {
                $terminal_array[$terminal->getTitle()] = $terminal;
            }
        }

        return $terminal_array;
    }

    /**
     * @param $params
     * @return mixed
     */
    private function selectOrder($params)
    {
        return Db::getInstance()->getRow('SELECT ' . _DB_PREFIX_ . 'valitor_order.*, '
        . _DB_PREFIX_ . 'valitor_transaction.amount FROM `'
        . _DB_PREFIX_ . 'valitor_order` INNER JOIN ' . _DB_PREFIX_ . 'valitor_transaction ON '
        . _DB_PREFIX_ . 'valitor_transaction.unique_id = ' . _DB_PREFIX_ . 'valitor_order.unique_id 
        WHERE id_order=' . $params['id_order']);
    }

    private function getOrderActions($paymentId)
    {
        $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'valitor_orderlines` WHERE valitor_payment_id = "' . $paymentId.'"';
        return Db::getInstance()->executeS($sql);
    }

    private function getOrderLine($paymentId, $productId)
    {
        return Db::getInstance()->executeS('SELECT ' . _DB_PREFIX_ . 'valitor_orderlines.* FROM `'
        . _DB_PREFIX_ . 'valitor_orderlines` 
        WHERE valitor_payment_id="' . $paymentId . '" AND product_id="'. $productId .'"');
    }

    private function populateOrderLinesFromPost($orderLines, $discountPercentage,$orderID,$productID,$prodcutAttributeID, $goodWillRefund = false)
    {
        $VALITOROrderLines = array();
        $i = 0;
    
        $ProductDetailObject = new OrderDetail;
        $product_detail = $ProductDetailObject->getList($orderID);
        $compensationQuantity = 0;
       

        foreach ($orderLines as $key => $orderedQuantity) {
            if ($orderedQuantity > 0) {

                $productDetails = $product_detail[$key];
                $productName = $productDetails['product_name'];


                $priceWithoutReductionTaxIncl = $productDetails['reduction_amount_tax_incl'] + $productDetails['unit_price_tax_incl'];
               
                //Calculation of base price
                $basePrice = $productDetails['reduction_amount_tax_excl'] + $productDetails['unit_price_tax_excl'];

                $discountAmount = $priceWithoutReductionTaxIncl - $productDetails['unit_price_tax_incl'];

                if ($discountAmount > 0 ) {
                    $discountPercentage = ($discountAmount /$priceWithoutReductionTaxIncl) * 100;
                } else {
                    foreach ($discountPercentage as $discountPer) {
                        $discountPercentage = $discountPer;
                    }
                }

                if ($productDetails['product_attribute_id']) {
                    $itemID = $productDetails['product_reference'].'-'.$productDetails['product_attribute_id'];
                } else {
                    $itemID = $productDetails['product_reference'];
                }

                $productQuantity = $orderedQuantity;
                $productTax = $priceWithoutReductionTaxIncl - $basePrice;
                $goodsType = 'item';

                if ($goodWillRefund) {
                    $goodsType = 'refund';
                } 
                //Looping into the product array to get the difference regarding compensation amount
                foreach($product_detail as $proKeys) {
                    $productPriceTaxIncl = $proKeys['total_price_tax_incl'];
                    $priceAfterDiscountRounded +=  (float) number_format($productPriceTaxIncl-($productPriceTaxIncl * ($discountPercentage/100)),2,'.','');
                    $priceAfterDiscount +=  bcadd($productPriceTaxIncl-($productPriceTaxIncl * ($discountPercentage/100)),0,2);
                    $totalQuantity += $proKeys['product_quantity'];

                }
                //Calculation of Total Compensation Amount
                $compensationAmount =  (float) number_format($priceAfterDiscountRounded - $priceAfterDiscount,2,'.','');
                $compensationAmountPerQuantity = $compensationAmount/$totalQuantity;
                
                //Get the Number of OrderLines in the Order
                end($product_detail);
                $totalOrderLines = key($product_detail)+1;

                //Calculation of Compensation Amount Per Product
                $compensationAmountPerOrderLine = $compensationAmount/$totalOrderLines;
              
                $totalProductsTaxAmount = (float)number_format($productTax * $productQuantity, 2, '.', '');
                // Mandatory keys for orderLines:
                $VALITOROrderLines[$i]['description'] = $productName; // Description of item.
                $VALITOROrderLines[$i]['itemId'] =  $itemID; // Item number (SKU)
                $VALITOROrderLines[$i]['quantity'] =  $productQuantity;
                // Unit price excluding sales tax, only two digits.
                $VALITOROrderLines[$i]['unitPrice'] = (float)number_format($basePrice, 2, '.', '');
                
                // Optional keys for orderLines:
                $VALITOROrderLines[$i]['taxAmount'] = $totalProductsTaxAmount  ; //Taxamount should be the total tax amount for order line.
                // The type of order line it is. Should be one of the following: shipment|handling|item|refund
                $VALITOROrderLines[$i]['goodsType'] = $goodsType;
                $VALITOROrderLines[$i]['discount'] = $discountPercentage;

                $compensationQuantity +=  $productQuantity;
            } else {
                continue;
            }
            $i++; 
        }
        if($compensationAmountPerQantity > 0) {

        $VALITOROrderLines[$i]['description'] = 'compensation'; // Description of item.
        $VALITOROrderLines[$i]['itemId'] =  'comp-1'; // Item number (SKU)
        $VALITOROrderLines[$i]['quantity'] =  1;
        // Unit price excluding sales tax, only two digits.
        $VALITOROrderLines[$i]['unitPrice'] =  $compensationQuantity*$compensationAmountPerQuantity;
        
        // Optional keys for orderLines:
        $VALITOROrderLines[$i]['taxAmount'] = 0  ; //Taxamount should be the total tax amount for order line.
        // The type of order line it is. Should be one of the following: shipment|handling|item|refund
        $VALITOROrderLines[$i]['goodsType'] = $goodsType;
        }  

        return $VALITOROrderLines;
    }

    private function createDummyOrderLinesArr($totalAmount)
    {
        $dummyItemOrderLine = array();
        // Mandatory keys for orderLines:
        $dummyItemOrderLine['description'] = 'Good-will refund';
        $dummyItemOrderLine['itemId'] =  '100200';
        $dummyItemOrderLine['quantity'] =  1;
        $dummyItemOrderLine['unitPrice'] =  $totalAmount;
        // Optional keys for orderLines:
        $dummyItemOrderLine['taxAmount'] = '0.00';
        $dummyItemOrderLine['taxPercent'] = '0.00';
        $dummyItemOrderLine['goodsType'] = 'refund';

        return array($dummyItemOrderLine);
    }

    /**
     * @param $arr
     * @return array
     */
    private function decodeHtmlEntitiesArrayValues($arr)
    {
        if (is_array($arr)) {
            foreach ($arr as $key => $value) {
                $arr[$key] = html_entity_decode($value, ENT_NOQUOTES);
            }
        }

        return $arr;
    }


    public function getTemplateVarInfos()
    {
        $cart = $this->context->cart;
        $currency = $this->getCurrencyForCart($cart);
        $paymentMethods = Terminal::getActiveTerminalsForCurrency($currency->iso_code);

        return array(
            'this_path' => $this->_path,
            'this_path_valitor' => $this->_path,
            'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/',
            'methods' => $paymentMethods,
            'PS_STOCK_MANAGEMENT' => Configuration::get('PS_STOCK_MANAGEMENT'),
        );
    }

    public function getCartDiscount() 
    {
        $appliedCoupon = $this->context->cart->getCartRules();
        foreach ($appliedCoupon as $code) {
            $discountPercent = $code['reduction_percent'];
        }
        
        return $discountPercent;
    }
}
